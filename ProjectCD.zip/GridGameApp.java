import gridgames.*;
import gridgameviews.*;
import collapse.*;
import minesweeper.*;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import org.apache.commons.cli.*;

/**
 * The GridGameApp class Runs the collapse application.
 * Depending on commandline arguments the Grid Game
 * is displayed as a GUI or as a console.
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public class GridGameApp
{
    private String boardfile;           //board file
    private String infile;              //input file
    private String outfile;             //output file
    private String pluginName;          //plug-in name
    private boolean showConsole;
    private boolean showGUI;

    /**
     * Runs the collapse application.
     * Depending on commandline arguments the Collapse game
     * is displayed as a GUI or/and as a console.
     * 
     * Command line usage:  java CollapseApp -cg [-b boardfile] [-i file1] [-o file2]
     *  -b,--board      predefined board file.
     *  -c,--console         use console
     *  -g,--gui             use gui
     *  -i,--infile     file to use instead of Standard Input.
     *  -o,--outfile    file to use instead of Standard OutInput.
     * 
     * @param args - the command line arguments passed to the app
     */
    @SuppressWarnings ("unchecked")
    public static void main(String[] args) throws Throwable
    {   
        GridGameApp app = new GridGameApp();

        //Deals with commandline arguments
        try
        {
            CommandLine cmd = app.getCommandLine(args);
            app.commandLineHandler(cmd);
        }
        catch (ParseException parseException)
        {
            System.out.println("Parse Exception: " + parseException.getMessage());
        }
        
        GridGameGUI gui;        
        GridGameConsole console;
        GridGame game;
        String gameName = "";      //used to display plug-in game name
        
        //Checks to see if there is a boardfile.
        if (app.boardfile == null)
        {
            //Creates an observable game to be observed
            //checks to see if provided pluginName
            if (args.length > 0)
            {
                //Takes the first command line argument and converts it into
                //type GridGame
                Class pluginClass = Class.forName(args[0]);
                gameName = args[0].substring(0, args[0].indexOf('.'));
                game = (GridGame) pluginClass.newInstance();
            }
            else
            {
                System.out.println("No plugin name provided.");
                game = null;
                System.exit(0);
            }
        }
        else
        {
            //Creates the game from boardfile.
            File file = new File(app.boardfile);
            Scanner scan = new Scanner(file);
            
            //Creates reflection class.
            Class pluginClass = Class.forName(args[0]);
            //Creates constructor arguments
            Object[] arguments = new Object[1];
            arguments[0] = scan;
            //Gets plugin constructor
            Constructor constructor = 
                pluginClass.getDeclaredConstructor(Scanner.class);
            
            //game = new CollapseGame();
            game = (GridGame) constructor.newInstance(arguments);
        }
        
        //Checks if should show GUI
        if (app.showGUI)
        {
            gui = new GridGameGUI(game);
            //Do the layout of widgets
            gui.layoutGUI();       

            //Make the GUI visible and available for user interaction
            gui.pack();
            
            //Adds GUI as observer to the game.
            game.addObserver(gui);
            game.getClock().addObserver(gui);
            gui.setVisible(true);
        }
        
        //Checks if should show console.
        if (app.showConsole)
        {
            try
            {
                //CollapseGUI gui = new CollapseGUI(); // (game)
                console = new GridGameConsole(game, app.infile, app.outfile);
                
                //Adds console as observer to the game.
                game.addObserver(console);
                
                game.startGame();
                console.run();
            }
            catch (FileNotFoundException exception)
            {
                System.out.println("File not found.");
            }
        }
        else
        {
            game.startGame();
        }
        
    }
    
    /**
     * Constructor for CollapseApp.
     * Sets display to be both console and gui.
     */
    public GridGameApp()
    {
        showConsole = false;
        showGUI = false;
    }
    
    /**
     * Reads the commandline using Apache Commons CLI library.
     * @param args - the command line arguments passed to the app
     * @return an apache commons CommandLine instance ready to be interrogated
     */
    public CommandLine getCommandLine(String[] args) 
        throws ParseException
    {
        //The options for the application
        Options options = new Options();
        
        //Makes so console and gui are mutually exclusive
        OptionGroup consoleOrGUI = new OptionGroup();
        //adds c and g options to group
        Option console = new Option("c", "console",  false, "use console");
        consoleOrGUI.addOption(console);
        Option gui = new Option("g", "gui", false, "use gui");
        consoleOrGUI.addOption(gui);
        //adds the mutually exclusive option group to options
        options.addOptionGroup(consoleOrGUI);
        
        //adds board file, input file, and output file options
        options.addOption("b", "board <arg>", true, "predefined board file.");
        options.addOption("i", "infile <arg>", true, 
            "file to use instead of Standard Input.");
        options.addOption("o", "outfile <arg>", true, 
            "file to use instead of Standard OutInput.");
        
        //Creates a parser in order to create a CommandLine instance
        CommandLineParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, args); 
        
        return cmd;
    }
    
    /**
     * Searches through the command line and sets appropriate 
     * file names and displays according to the options.
     * @param cmd - the CommandLine instance
     */
    public void commandLineHandler(CommandLine cmd)
    {
        //Checks to see if console was set.
        if (cmd.hasOption('c'))
        {
            showConsole = true;
            infile = cmd.getOptionValue("i");
            outfile = cmd.getOptionValue("o");
        }
        //Checks to see if gui was set
        else if (cmd.hasOption('g'))
        {
            showGUI = true;
        }
        else
        {
            infile = cmd.getOptionValue("i");
            outfile = cmd.getOptionValue("o");
        }
        
        boardfile = cmd.getOptionValue("b");
    }
    
}
