package minesweeper;

import gridgames.*;
/**
 * A Minesweeper player entry for the Hall of Fame.
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public class MinesweeperEntry extends PlayerEntry
{
    private String name;
    private String time;
    
    private final static int kSecsInMin = 60;
    private final static int kNonSingleDigit = 10;
    
    /**
     * Creates a minesweeper entry from Players name and score.
     * Score is the number of moves it took to win the game.
     * @param name - player's name 
     * @param time - time it took to win
     */
    public MinesweeperEntry(String name, String time)
    {
        this.name = name;
        this.time = time;
    }
    
    /**
     * Returns the name of the player.
     * @return name of the player
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Returns the name of the player.
     * @param name - of the player
     */
    public void setName(String name)
    {
        this.name = name;
    }
    
    /**
     * Returns the attribute that the plug-in author wants to
     * sort the hall of fame by.
     * 
     * @return the entry's attribute as a string (score, time, etc.)
     */
    public String getAttribute()
    {
        return time;
    }
    
    /**
     * Returns the time in seconds elapsed.
     * @return time
     */
    public int getTime()
    {
        int curChar = 0;
        int timeInSeconds = 0;
        
        timeInSeconds += Integer.parseInt(time.charAt(curChar++) + "") * kSecsInMin;
        curChar++;
        timeInSeconds += Integer.parseInt(time.charAt(curChar++) + "") * kNonSingleDigit;
        timeInSeconds += Integer.parseInt(time.charAt(curChar) + "");
        
        return timeInSeconds;
    }

    /**
     * Returns the type of attribute that the plug-in author wants to
     * sort the hall of fame by.
     *  ex. "score", "time", etc.
     * @return the name of the attribute type
     */
    public String getAttributeType()
    {
        return "time";
    }
    
    /**
     * Must override equals method.
     * @param other - object to compare to
     * @return whether or not the play entries are equal
     */
    @Override
    public boolean equals(Object other)
    {
        boolean isEqual = true;
        PlayerEntry entry = (PlayerEntry) other;
        
        //Checks if other object is a Collapse Entry
        if (!(other instanceof MinesweeperEntry))
        {
            isEqual = false;
        }
        //Checks to see if they have the same name
        else if (!this.name.equals(entry.getName()))
        {
            isEqual = false;
        }
        // Checks to see if have same score.
        else if (!this.getAttribute().equals(entry.getAttribute()))
        {
            isEqual = false;
        }
        
        return isEqual;
    }
    
    /**
     * Must implement compareTo method.
     * @param other - object to compare to
     * @return -1 if less than, 0 if equal, 1 if greater than
     */
    public int compareTo(Object other)
    {
        int toRet = 0;
        
        MinesweeperEntry entry = (MinesweeperEntry) other;
        // Checks to see if score is less
        if (this.getTime() < entry.getTime())
        {
            toRet = 1;
        }
        //Checks to see if score is greater
        else if (this.getTime() > entry.getTime())
        {
            toRet = -1;
        }
        
        return toRet;
    }
    
    /**
     * Returns name and score, spaced out.
     * @return name and score as a String
     */
    public String toString()
    {
        return getName() + "    " + getAttribute();
    }
}
