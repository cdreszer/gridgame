package minesweeper;

import gridgames.*;
import javax.swing.*;
import java.awt.event.*;


/**
 * The new game action makes a new instance of the grid game.
 * 
 * @author Chase Dreszer 
 * @version Nov 2015
 * 
 */
public class PeekAction extends GridAction
{
    //the game to restart
    private MinesweeperGame game;
    
    /**
     * The constructor for a GridAction allows for the author to assign a label
     * to the action, an icon for the action, and an accelerator for the action.
     * 
     * @param label - the name of the action to appear in the menu
     * @param icon - the icon to appear next to the name if any
     * @param mnemonic - the keyboard shortcut for the action
     * @param game - the game to perform the action on
     */
    public PeekAction(String label, ImageIcon icon,
                      Integer mnemonic,
                      MinesweeperGame game)
    {
        super(label, icon, mnemonic);
        this.game = game;
    }
    
    /**
     * Performs a restart on the grid game.
     * @param event - the action event.
     */
    public void actionPerformed(ActionEvent event) 
    {
        game.peek();
    }
}
