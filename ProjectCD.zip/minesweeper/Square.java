package minesweeper;
import gridgames.*;
import java.util.*;

/**
 * The Tile class models the colored, rectangular tiles within the playing area./
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class Square implements MyRenderable
{
    private char symbol;        //Symbol representing color
    private boolean isHidden = true;
    private boolean isFlagged = false;
    
    private String pkg = "/Minesweeper/";
    private String folder = "KaboomImages/";
    private String bomb = "bomb.jpg";
    private String explodedBomb = "exploded.jpg";
    private String flagged = "flagged.jpg";
    private String hidden = "hidden.jpg";
    

    /**
     * Constructor for objects of class Tile
     */
    public Square()
    {
        this.symbol = ' ';
    }
    
    /**
     * Sets tile to specified color/symbol.
     * @param symbol - the symbol to be read in
     */
    public Square(char symbol)
    {
        this.symbol = symbol;
    }
   
    /**
     * Returns the tile's symbol
     * @return symbol as a char
     */
    public char getSymbol()
    {
        char sym;
        
        //checks if isHidden
        if (isHidden && !isFlagged)
        {
            sym = '-';
        }
        //checks if flagged
        else if (isHidden && isFlagged)
        {
            sym = '@';
        }
        else
        {
            sym = symbol;
        }
        
        return sym;
    }
    
    /**
     * Returns whether or not the renderable cell contains an image.
     * 
     * @return whether or not the cell contains an image
     */
    public boolean isImage()
    {
        boolean isImage = false;
        
        // Checks to see if bomb, exploded bomb, flagged, or is hidden
        if (symbol == 'B' || symbol == '*' || symbol == 'F' || isHidden)
        {
            isImage = true;
        }
        
        
        return isImage;
    }
    
    /**
     * Returns the text the plug-in author wants to display in a
     * cell. 
     * 
     * @return the text that should be displayed in a cell formatted as 
     *  startTags + text + endTags.
     */
    public String htmlText()
    {
        return kStartTags + symbol + kEndTags;
    }
    
    /**
     * Randomizes the color of the tile.
     * 
     */
    public void randomizeSquare()
    {
        
    }
    
    /**
     * Returns whether or not the square is hidden.
     * 
     * @return whether or not tile will be removed.
     */
    public boolean isHidden()
    {
        return isHidden;
    }
    
    /**
     * Places a flag in the square.
     */
    public void placeFlag()
    {
        isFlagged = true;
    }
    
    /**
     * Removes the flag from the square.
     */
    public void removeFlag()
    {
        isFlagged = false;
    }
    
    /**
     * Returns whether or not the square is flagged.
     * 
     * @return whether or not tile will be removed.
     */
    public boolean isFlagged()
    {
        return isFlagged;
    }
    
    /**
     * Unhides the square, showing whether the square is empty or 
     * contains a bomb.
     */
    public void setHidden()
    {
        isHidden = true;
    }
    
    /**
     * Unhides the square, showing whether the square is empty or 
     * contains a bomb.
     */
    public void unhide()
    {
        isHidden = false;
    }
    
    /**
     * True value of the square.
     * @return the true value of the square (not if hidden or flagged)
     */
    public char getTrueValue()
    {
        return symbol;
    }
    
    /**
     * Returns the squares symbol
     * @return symbol
     */
    public String getText() 
    { 
        String toRet = "";
        //checks if isHidden
        if (isHidden && !isFlagged)
        {
            toRet = "-";
        }
        //checks if flagged
        else if (isHidden && isFlagged)
        {
            toRet = "@";
        }
        else
        {
            toRet += symbol;
        }
        return toRet; 
    }
    
    /**
     * Returns the squares symbol.
     * @return symbol
     */
    @Override
    public String toString() 
    { 
        String toRet = "";
        //checks if isHidden
        if (isHidden && !isFlagged)
        {
            toRet = "-";
        }
        //checks if flagged
        else if (isHidden && isFlagged)
        {
            toRet = "@";
        }
        else
        {
            toRet += symbol;
        }
        return toRet;  
    }
    
    /**
     * Returns a map of all the renderable token's names 
     * for the grid game mapped with the file path to their images, if anything.
     * 
     * Key = piece name
     * Value = path to image
     * 
     * @return map of piece names and images
     */
    public Map<Character, String> getRenderableImageMap()
    {
        Map<Character, String> tileImages = new HashMap<Character, String>();
        
        tileImages.put('-', pkg + folder + hidden);
        tileImages.put('*', pkg + folder + explodedBomb);
        tileImages.put('B', pkg + folder + bomb);
        tileImages.put('@', pkg + folder + flagged);
        
        return tileImages;
    }

}
