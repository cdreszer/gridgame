package minesweeper;

import gridgames.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * The ObservableArea contains the status and playing area.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class MinesweeperGame extends GridGame
{
    private MinesweeperPlayingArea area;
    private GameClock clock;
    private Preferences preferences;
    //private boolean hasQuit;
    private int size;
    private boolean showHOF = false;
    private final int kSizeOfHOF = 5;
    
    /**
     * Creates a new Minesweeper game with default settings.
     * Initialize the board to a random configuration with number
     * of bombs based on size and difficulty. 
     */
    public MinesweeperGame()
    {
        super();
        //intializes size of game (gets default size)
        size = super.initialSize();
        preferences = getPreferences();
        //gets the clock
        clock = super.getClock();
        //Creates new instance of playing area of correct size
        area = new MinesweeperPlayingArea(this.size);
    }
    
    /**
     * Creates a new Minesweeper game by reading a predefined board 
     * configuration with which to start the game.
     * @param scan Scanner from which a board configuration is read. 
     */
    public MinesweeperGame(Scanner scan)
    {
        size = super.initialSize();
        preferences = getPreferences();
        //area = (CollapsePlayingArea) super.getArea();
        area = new MinesweeperPlayingArea(size);
        area = (MinesweeperPlayingArea) setGridGame(area, scan);
        area.recalcBombCount();
        clock = super.getClock();
        refresh();
    }
    
    /**
     * Returns the status panel as a string to be put into "status".
     * @return a string representing the status of the game.
     */
    public String getStatus()
    {   
        return "Moves: " + area.getMoveCount() + "   Flags: " + 
            area.getFlagCount() + "/" + area.getBombCount() + 
                "  " + clock.getTime();
    }
    
    /**
     * Returns the PlayingArea of the game.
     * @return the playing area
     */
    public PlayingArea getArea()
    {
        return area;
    }
    
    /**
     * Returns the size of the game.
     * @return size of the board
     */
    public int getSize()
    {
        size = area.getColumnCount();
        return size;
    }
    
        
    /**
     * Carries out minesweeper logic for the specified value being left clicked.
     * @param rowIndex - row location of click
     * @param columnIndex - col location of click
     */
    public void valueAtLeftClicked(int rowIndex, int columnIndex)
    {
        //Checks to see if the value selected is empty
        if (((Square)(area.getValueAt(rowIndex, columnIndex))).getSymbol() == '-'
            || ((Square)(area.getValueAt(rowIndex, columnIndex))).getSymbol() == '@')
        {
            //sets corresponding spot in playing area
            area.valueAtLeftClicked(rowIndex, columnIndex);
            
            setChanged();
            notifyObservers();
        }
        
        //Checks if tile count is at 0
        if (area.hasLost() || !area.hasPlayableMove())
        {
            clock.stopTimer();
        }
    }
    
    /**
     * Carries out minesweeper logic for the specified value being right clicked.
     * @param rowIndex - row location of click
     * @param columnIndex - col location of click
     */
    public void valueAtRightClicked(int rowIndex, int columnIndex)
    {
        //Checks to see if the value selected is empty
        if (((Square)(area.getValueAt(rowIndex, columnIndex))).getSymbol() == '-'
            || ((Square)(area.getValueAt(rowIndex, columnIndex))).getSymbol() == '@')
        {
            //sets corresponding spot in playing area
            area.valueAtRightClicked(rowIndex, columnIndex);
            
            setChanged();
            notifyObservers();
        }
        
        //Checks if tile count is at 0
        if (area.hasLost() || !area.hasPlayableMove())
        {
            clock.stopTimer();
        }
    }
    
    /**
     * Restarts the game.
     */
    public void restartGame()
    {
        //restarts click count and resets up same playing area
        area.restartArea(); 
        //resets status panel
        clock.resetTimer();
        refresh();
    }
    
    /**
     * Creates a new game.
     */
    public void newGame()
    {
        TreeMap<String, TreeMap<String, String>> prefs = 
            preferences.getPreferenceValues();
            
        TreeMap<String, String> curPreferences = 
            preferences.getCurPreferences();
        
        String curBoard = curPreferences.get("Board Size");
        String newSize = prefs.get("Board Size").get(curBoard);

        //makes sure new size not null
        if (newSize != null)
        {
            area.setSize(Integer.parseInt(newSize));
        }
        
        String curDiff = curPreferences.get("Difficulty");
        String newVal = prefs.get("Difficulty").get(curDiff);

        //makes sure new value not null
        if (newVal != null)
        {
            area.setSize(Integer.parseInt(newSize));
            area.setDifficulty(Integer.parseInt(newVal));
        }
        
       
        
        //rerandomizes game and resets click count
        area.randomizePlayingArea();
        //reseys timer and prints status
        clock.resetTimer();
        refresh();
    }
    
        
    /**
     * There is a Peek function that reveals the entire board, 
     * which is of course only for people of low moral stature. 
     */
    public void peek()
    {
        area.peek();
        refresh();
    }
    
    
    /**
     * To facilitate testing, there is a Cheat function that clears 
     * the entire game board except for two tiles in the upper left 
     * corner (but doesn't win the game).  The left-most tile hides a 
     * bomb, and the right-most tile hides a "1".  If the user clicks 
     * on the right-most tile, the square is revealed and they win.  
     * (Clicking on the bomb loses the game as expected). If the user 
     * cheats and wins (or loses) and then clicks cheat again, the tiles
     * show up again. 
     * 
     */
    public void cheat()
    {
        area.cheat();
        refresh();
    }
    
    /**
     * Checks to see if the game has been won
     * @return whether or not the game has been won
     */
    public boolean hasWon()
    {
        return !area.hasPlayableMove();
    }
    
    /**
     * Returns a list of menu actions for the observable game.
     * @return list of menu actions
     */
    public List<Action> getMenuActions()
    {
        
        Action restart = new RestartAction("Restart", null, KeyEvent.VK_R, this);
        Action newGame = new NewGameAction("New", null, KeyEvent.VK_N, this);
        Action hof = new HOFAction("Hall", null, KeyEvent.VK_H, this);
        Action peek = new PeekAction("Peek", null, KeyEvent.VK_P, this);
        Action cheat = new CheatAction("Cheat", null, KeyEvent.VK_C, this);
        Action quit = new QuitAction("Quit", null, KeyEvent.VK_Q, this);
        
        List<Action> actions = new ArrayList<Action>();
        
        actions.add(restart);
        actions.add(newGame);
        actions.add(hof);
        actions.add(peek);
        actions.add(cheat);
        actions.add(quit);
        
        return actions;
    }
    
    /**
     * Returns a list of preference actions for the observable game.
     * @return list of pref actions
     */
    
    public List<Action> getPreferenceActions()
    {
        
        //creates action list
        List<Action> actions = new ArrayList<Action>();
        //gets key values
        TreeMap<String, String> values = 
            getPreferences().getPreferenceValues().get("Board Size");
            
        //gets small value
        String sSize = values.get("small");
        int vSize = Integer.parseInt(sSize);
            
        Action smallAction = new SizeAction("small", null, null, this, vSize);

        sSize = values.get("medium");
        vSize = Integer.parseInt(sSize);
            
        Action medAction = new SizeAction("medium", null, null, this, vSize);
        
        sSize = values.get("large");
        vSize = Integer.parseInt(sSize);
            
        Action largeAction = new SizeAction("large", null, null, this, vSize);
        
        values = 
            getPreferences().getPreferenceValues().get("Difficulty");
        
        //gets wasyvalue
        sSize = values.get("easy");
        vSize = Integer.parseInt(sSize);
            
        Action easyAction = new DifficultyAction("easy", null, null, this, vSize);

        sSize = values.get("moderate");
        vSize = Integer.parseInt(sSize);
            
        Action modAction = new DifficultyAction("moderate", null, null, this, vSize);
        
        sSize = values.get("hard");
        vSize = Integer.parseInt(sSize);
            
        Action hardAction = new DifficultyAction("hard", null, null, this, vSize);

        actions.add(smallAction);
        actions.add(medAction);
        actions.add(largeAction);
        actions.add(easyAction);
        actions.add(modAction);
        actions.add(hardAction);
        
        return actions;
    }
    
    
    /**
     * Returns the path to the background image.
     * Returns null if no background image.
     * 
     * @return background image
     */
    public String getBackgroundImagePath()
    {
        return "minesweeper/KaboomImages/bkgd.jpg";
    }
    
    /**
     * Returns the name of the plug-in.
     * Used when searching for configuration files.
     * @return name of the plug-in
     */
    public String getPluginName()
    {
        return "minesweeper";
    }
    
    /**
     * Returns the PlayerEntry to be entered into the HOF.
     * @return the HOF player entry
     */
    public PlayerEntry getPlayerEntry()
    {
        PlayerEntry entry = new MinesweeperEntry("", clock.getTime());
        
        return entry;
    }
    
    /**
     * Returns an instance of the HallOfFame for the current game.
     * @return HallOfFame (filename, size, how many to be displayed)
     */
    public HallOfFame<PlayerEntry> getHallOfFame()
    {
        return new HallOfFame<PlayerEntry>(
            "minesweeper/HOF.txt", kSizeOfHOF, kSizeOfHOF);
    }
}
