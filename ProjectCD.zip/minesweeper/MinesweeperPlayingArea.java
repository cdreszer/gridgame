package minesweeper;

import gridgames.*;
import javax.swing.table.AbstractTableModel;
import java.util.*;

/**
 * The PlayingArea class represents the playing area for the Collapse game.
 * 
 * The playing area consists of a pattern of colored rectangular tiles. 
 * When the game starts the playing area is covered with 64 tiles 
 * in a 8 by 8 grid. 
 * 
 * The size of the playing area is adjustable, but is always a square.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class MinesweeperPlayingArea extends PlayingArea
{
    /** Represents the the 2D area */
    private MyRenderable[][] myArea;
    private String[] columns;
    // saves original format of area
    private MyRenderable[][] restartableArea;
    //saves format of area before each move
    private Stack<MyRenderable[][]> undoArea; 
    
    //private GameState state = new GameState();
    private MinesweeperLogic logic;
    
    private int size;           //Size of the playing area.
    private int moveCount;
    private int flagCount;
    private int bombCount;
    private int emptyTileCount;
    private int difficulty = 8;
    
    private final static int kMaxSize = 12;
    
    /**
     * Constructs a playing area of the specified size.
     * @param size - size of the playing area
     */
    public MinesweeperPlayingArea(int size)
    {
        //sets size of area to specified size
        this.size = size;
        bombCount = (size * size) / difficulty;
        
        undoArea = new Stack<MyRenderable[][]>(); 
        
        //sets tile and move count
        moveCount = 0;
        
        //instantiates playing area
        myArea = new Square[kMaxSize][kMaxSize];
        //myArea = new Tile[size][size];
        
        setColumns(size);
        restartableArea = new Square[kMaxSize][kMaxSize];

        setSize(size);
        //System.out.println(myArea.length + "x" + myArea[0].length);
    }
    
    /**
     * Set columns so PlayingArea displays properly.
     * @param gameSize - size of playing area.
     */
    private void setColumns(int gameSize)
    {
        columns = new String[gameSize];
        
        //Sets all columns to ""
        for (int ndx = 0; ndx < gameSize; ndx++)
        {
            columns[ndx] = "";
        }
    }
    
    /**
     * Sets the playing area size and restarts.
     * 
     * @param newSize - size of the new playing area
     */
    public void setSize(int newSize)
    {
        clearPlayingArea();
        //sets size to new size passed
        this.size = newSize;
        bombCount = (size * size) / difficulty;
        
        //Sets new dimensions
        myArea = new Square[size][size];
        restartableArea = new Square[size][size];

        this.fireTableChanged(null);
        
        //System.out.println(myArea.length + "x" + myArea[0].length);
        //sets columns to match
        setColumns(size);
        
        //randomizes the area
        //updates the JTable
        this.fireTableStructureChanged();
        
        randomizePlayingArea();
    }
    
    /**
     * Sets the difficulty of the game
     * 
     * @param difficulty - new difficulty
     */
    public void setDifficulty(int difficulty)
    {
        this.difficulty = difficulty;
    }
    
    /**
     * Returns columns so number of columns will be displayed properly.
     * @return columns
     */
    public String[] getColumns()
    {
        return columns;
    }
        
    /**
     * Returns 2D array of tiles.
     * @return my area
     */
    public MyRenderable[][] getArea()
    {
        return myArea;
    }
    
    /**
     * Randomizes all the tiles in the playing area.
     * Most useful when starting a new game.
     */
    public void randomizePlayingArea()
    {
        moveCount = 0;
        bombCount = (size * size) / difficulty;
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                myArea[row][col] = new Square();
                //Saves restartable area
                //restartableArea[row][col] = new Square();
            }
        }
        
        //Sets the bombs randomly in the playing area.
        for (int bomb = 0; bomb < bombCount; bomb++)
        {
            int randomRow = (int) (Math.random() * size);
            int randomCol = (int) (Math.random() * size);
            
            myArea[randomRow][randomCol] = new Square('B');
            //restartableArea[randomRow][randomCol] = new Square('B');
        }
        
        logic = new MinesweeperLogic(myArea, size);
        
        myArea = logic.setupNumbersOnBoard();
        
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Saves restartable area
                restartableArea[row][col] = 
                    new Square(((Square) myArea[row][col]).getTrueValue());
            }
        }
        
        this.fireTableChanged(null);
        
    }
    
    /**
     * Returns the number of rows in the playing area.
     * @return num rows
     */
    @Override
    public int getRowCount() 
    {
        // Since the playing area is a square, num rows = size
        return size;
    }

    /**
     * Returns the number of columns in the playing area.
     * @return num columns
     */
    @Override
    public int getColumnCount() 
    {
        // Since the playing area is a square, num columns = size
        return size;
    }
   
    /**
     * Returns the value in the playing area corresponding to
     * the row index and column index.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @return object
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        return myArea[rowIndex][columnIndex];
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void valueAtLeftClicked(int rowIndex, int columnIndex) 
    {
        moveCount++;
        logic = new MinesweeperLogic(myArea, size);
        
        myArea = logic.doLeftMove(rowIndex, columnIndex);
        
        fireTableDataChanged();
        
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void valueAtRightClicked(int rowIndex, int columnIndex) 
    {
        moveCount++;
        logic = new MinesweeperLogic(myArea, size);
        
        //Checks to see if clicked on hidden spot.
        if (((Square)myArea[rowIndex][columnIndex]).isHidden())
        {
            myArea = logic.doRightMove(rowIndex, columnIndex);
            flagCount++;
        }
        
        fireTableDataChanged();
    }
    
    /**
     * Sets the Tile in the playing area corresponding to
     * the row index and column index to the color/symbol specified.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol the tile is to be set to
     */
    public void setValueAt(int rowIndex, int columnIndex, char symbol)
    {
        //Sets value to the symbol passed
        myArea[rowIndex][columnIndex] = new Square(symbol);
        
        fireTableDataChanged();
    }
    
    /**
     * Sets current playingArea to restart.
     * Used during configured boards.
     */
    public void setRestart()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Saves restartable area
                restartableArea[row][col] = new Square(
                    ((Square) myArea[row][col]).getTrueValue());
            }
        }
        
        //Makes sure no undoable moves to begin
        while (!undoArea.isEmpty())
        {
            undoArea.pop();
        } 
    }
        
    /**
     * Restarts the playing area to it's original form.
     */
    public void restartArea()
    {
        undoArea = new Stack<MyRenderable[][]>();
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //instantiates each tile in the playing area.
                //myArea[row][col] = restartableArea[row][col];
                setValueAt(row, col, 
                    ((Square) restartableArea[row][col]).getTrueValue());
            }
        }
        
        moveCount = 0;
      
    }
    
    /**
     * Returns the amount of moves that have been done in the playing area.
     * @return tile count
     */
    public int getMoveCount()
    {
        return moveCount;
    }
    
    /**
     * Returns the amount of bombs that have been placed in the playing area.
     * @return bomb count
     */
    public int getBombCount()
    {
        return bombCount;
    }
    
    /**
     * Returns the amount of flags that have been placed in the playing area.
     * @return flag count
     */
    public int getFlagCount()
    {
        return flagCount;
    }
    
    /**
     * Clears the entire playing area.
     * Used when resizing playing area.
     */
    public void clearPlayingArea()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //sets tile to empty
                myArea[row][col] = new Square(' ');
            }
        }
    }
    
    /**
     * There is a Peek function that reveals the entire board, 
     * which is of course only for people of low moral stature. 
     */
    public void peek()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //sets tile to empty
                ((Square) myArea[row][col]).unhide();
            }
        }
        
        this.fireTableChanged(null);
        
    }
    
    /**
     * To facilitate testing, there is a Cheat function that clears 
     * the entire game board except for two tiles in the upper left 
     * corner (but doesn't win the game).  The left-most tile hides a 
     * bomb, and the right-most tile hides a "1".  If the user clicks 
     * on the right-most tile, the square is revealed and they win.  
     * (Clicking on the bomb loses the game as expected). If the user 
     * cheats and wins (or loses) and then clicks cheat again, the tiles
     * show up again. 
     * 
     */
    public void cheat()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Clears the rest of the playing area
                myArea[row][col] = new Square(' ');
                ((Square) myArea[row][col]).unhide();
            }
        }
        
        //sets the upper left corner to B and 1
        myArea[0][1] = new Square('1');
        myArea[0][0] = new Square('B');
        bombCount = 1;
        
        this.fireTableChanged(null);
        
    }
    
    /**
     * Checks to see if the user has lost the game.
     * @return whether the game has been lost
     */
    public boolean hasLost()
    {
        logic = new MinesweeperLogic(myArea, size);
        
        return logic.hasLost();
    }
    
    /**
     * Checks to see if all hidden squares remaining are bombs.
     * If so returns playable as false.
     * @return whether the game is still playable
     */
    public boolean hasPlayableMove()
    {
        int hiddenLeft = 0;
        
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Checks to see if square is hidden
                if (myArea[row][col].getSymbol() == '-'
                    || myArea[row][col].getSymbol() == '@')
                {
                    hiddenLeft++;
                }
            }
        }
        
        
        return hiddenLeft != bombCount;
    }
    
    /**
     * Recalculates bomb count.
     * Useful if configured board.
     */
    public void recalcBombCount()
    {
        bombCount = 0;
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Checks to see if square is hidden
                if (((Square) myArea[row][col]).getTrueValue() == 'B')
                {
                    bombCount++;
                }
            }
        }
    }
    
    /**
     * Sets up the starting playing area.
     */
    public void setupStartingPlayingArea()
    {
        myArea = new Square[kMaxSize][kMaxSize];
        super.setPlayingArea(myArea);
    }
}
