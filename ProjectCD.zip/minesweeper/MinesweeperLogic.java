package minesweeper;

import gridgames.*;

/**
 * The MinesweeperLogic class is used to take care of all neighbor checking
 * and number assigning within the Minesweeper Game.
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public class MinesweeperLogic 
{

    /** Playing area to use collapse logic on*/
    private Square[][] myArea;
    private int size;           //size of playing area
    private final int kAsciiZero = 48;
    //private GameState state;
    
    /**
     * Specifies the direction. Used when searching neighboring tiles.
     */
    public enum Direction
    {
        UP, DOWN, LEFT, RIGHT, UP_LEFT, UP_RIGHT, DOWN_LEFT, DOWN_RIGHT;
    }
    
    /**
     * Constructor for objects of class CollapseLogic
     * @param myArea - playing are to be used
     * @param size - size of playing area
     */
    public MinesweeperLogic(MyRenderable[][] myArea, int size)
    {
        this.myArea = (Square[][]) myArea;
        this.size = size;       
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row of click
     * @param columnIndex - col of click
     * @return updated playing area
     */
    public MyRenderable[][] doLeftMove(int rowIndex, int columnIndex)
    {
        //checks under the hidden square
        myArea[rowIndex][columnIndex].unhide();
        
        //checks to see if the hidden square is a bomb
        if (myArea[rowIndex][columnIndex].getSymbol() == 'B')
        {
            //explodes the bomb if so
            myArea[rowIndex][columnIndex] = new Square('*');
            myArea[rowIndex][columnIndex].unhide();
            unhideAllSquares();
            //hasLost = true;
        }
        
        //checks to see if the hidden square is empty
        if (myArea[rowIndex][columnIndex].getSymbol() == ' ')
        {
            checkNeighborsForEmpty(rowIndex, columnIndex);
        }
        
        return myArea;
    }
    
    /**
     * Checks to see if the user has lost the game.
     * @return whether the game has been lost
     */
    public boolean hasLost()
    {
        boolean hasLost = false;
        
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //checks to see if square is empty
                if (myArea[row][col].getTrueValue() == '*')
                {
                    hasLost = true;
                }
                
            }
        }
        
        return hasLost;
    }
    
    /**
     * Sets up the numbers on the board around the bombs.
     * @return the board with numbers where necessary
     */
    public MyRenderable[][] setupNumbersOnBoard()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //checks to see if square is empty
                if (myArea[row][col].getTrueValue() == ' ')
                {
                    checkNeighborsForBomb(row, col);
                }
                
            }
        }
        
        return myArea;
    }
    
    /**
     * Checks neighbors of clicked on tile.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void checkNeighborsForBomb(int rowIndex, int columnIndex)
    {
        char myNum = '1';
        //Checks if there is a neighbor of same color
        //Setting tile to disappear if any matches
        //Checks left
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.LEFT))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //Checks right
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.RIGHT))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //Checks up
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.UP))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //Checks down
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.DOWN))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //checks up left
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.UP_LEFT))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //Checks up right
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.UP_RIGHT))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //Checks down left
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.DOWN_LEFT))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
        //Checks down right
        if (checkDirectionForBomb(rowIndex, columnIndex, 'B', Direction.DOWN_RIGHT))
        {
            myArea[rowIndex][columnIndex] = new Square(myNum++);
            //myArea[rowIndex][columnIndex].unhide();
        }
       
    }
    
    /**
     * Checks neighbors of clicked on tile.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void checkNeighborsForEmpty(int rowIndex, int columnIndex)
    {
        myArea[rowIndex][columnIndex].unhide();
        //Checks if there is a neighbor of same color
        //Setting tile to disappear if any matches
        //Checks left
        checkDirectionForEmpty(rowIndex, columnIndex, ' ', Direction.LEFT);

        //Checks right
        checkDirectionForEmpty(rowIndex, columnIndex, ' ', Direction.RIGHT);

        //Checks up
        checkDirectionForEmpty(rowIndex, columnIndex, ' ', Direction.UP);

        checkDirectionForEmpty(rowIndex, columnIndex, ' ', Direction.DOWN);

    }
    
    /**
     * Alters the row number depending on the direction given.
     * @param row - the row number to change from
     * @param dir - the direction to go
     * @return the new row index
     */
    public int alterRow(int row, Direction dir)
    {
        int newRow = row;
        
        //Checks if direction is up and changes row
        if (dir == Direction.UP || dir == Direction.UP_LEFT 
            || dir == Direction.UP_RIGHT)
        {
            newRow--;
        }
        //checks if direction is down and changes row
        if (dir == Direction.DOWN || dir == Direction.DOWN_LEFT 
            || dir == Direction.DOWN_RIGHT)
        {
            newRow++;
        }
        
        return newRow;
    }
    
    /**
     * Alters the row number depending on the direction given.
     * @param col - the column number to change from
     * @param dir - the direction to go
     * @return the new column index
     */
    public int alterColumn(int col, Direction dir)
    {
        int newCol = col;
        
        //checks if direction is left and changes col
        if (dir == Direction.LEFT || dir == Direction.DOWN_LEFT
            || dir == Direction.UP_LEFT)
        {
            newCol--;
        }
        //checks if direction is right and changes col
        if (dir == Direction.RIGHT || dir == Direction.DOWN_RIGHT
            || dir == Direction.UP_RIGHT)
        {
            newCol++;
        }
        
        return newCol;
    }
    
    /**
     * Checks to see if the direction is diagonal.
     * @param dir - the direction to check
     * @return whether or not the direction is diagonal
     */
    public boolean isDiagonal(Direction dir)
    {
        boolean isDiagonal = false;
        //Checks if diagonal
        if (dir == Direction.DOWN_RIGHT || dir == Direction.UP_RIGHT
            || dir == Direction.DOWN_LEFT || dir == Direction.UP_LEFT)
        {
            isDiagonal = true;
        }
        
        return isDiagonal;
    }
    
    /**
     * Checks if the neighboring tile to the specified direction
     * is of the same color/symbol as the current tile.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol of the current tile
     * @param dir - direction to check neighbor
     * @return whether or not a neighbor is the same color
     */
    private boolean checkDirectionForBomb(int rowIndex, 
        int columnIndex, char symbol, Direction dir)
    {
        int newRow = alterRow(rowIndex, dir);
        int newCol = alterColumn(columnIndex, dir);
        boolean isDiagonal = isDiagonal(dir);
        
        //Makes sure new row/col is not out of bounds
        if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size)
        {
            //Checks if neighbor has the same symbol
            if (myArea[newRow][newCol].getTrueValue() == symbol)
            {
                return true;
            }
            
        }
        
        return false;
    }
    
        /**
     * Checks if the neighboring tile to the specified direction
     * is of the same color/symbol as the current tile.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol of the current tile
     * @param dir - direction to check neighbor
     * @return whether or not a neighbor is the same color
     */
    private boolean checkDirectionForEmpty(int rowIndex, 
        int columnIndex, char symbol, Direction dir)
    {
        int newRow = alterRow(rowIndex, dir);
        int newCol = alterColumn(columnIndex, dir);
        boolean isDiagonal = isDiagonal(dir);
        
        //Makes sure new row/col is not out of bounds
        if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size)
        {
            //Checks to see if is hidden and empty... if so checks neighbors
            //Makes sure spot coming from is empty
            if (myArea[newRow][newCol].isHidden() && 
                myArea[newRow][newCol].getTrueValue() == ' ')
            {
                checkNeighborsForEmpty(newRow, newCol);
            }
            // If the square isn't a bomb, unhide it
            if (myArea[newRow][newCol].getTrueValue() != 'B')
            {
                myArea[newRow][newCol].unhide();
            }
            
        }
        
        return false;
    }
    
    /**
     * Unhides all the squares in the playing area.
     */
    public void unhideAllSquares()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //sets tile to empty
                myArea[row][col].unhide();
            }
        }
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row of click
     * @param columnIndex - col of click
     * @return updated playing area
     */
    public MyRenderable[][] doRightMove(int rowIndex, int columnIndex)
    {
        //If the square clicked on is hidden... mark it with a flag
        if (myArea[rowIndex][columnIndex].isHidden())
        {
            //Checks if there is no flag already there
            if (!myArea[rowIndex][columnIndex].isFlagged())
            {
                myArea[rowIndex][columnIndex].placeFlag();
            }
            else
            {
                //removes the flag
                myArea[rowIndex][columnIndex].removeFlag();
            }
        }
        
        return myArea;
    }
}
