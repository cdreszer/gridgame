import java.util.*;
import java.io.*;

/**
 * The CollapseAppTest class tests the Collapse app.
 *
 * @author  Chase Dreszer
 * @version Nov 2015
 */
public class GridGameAppTest extends junit.framework.TestCase
{

    private String output = "outputfile2.txt";
    private String input = "inputfile2.txt";
    private String expected = "expectedout2.txt";
    
    public void testMain()
    {
        GridGameApp app = new GridGameApp();
        String[] args = {"collapse.CollapseGame", "-c", 
            "-b", "test.txt", "-i", input, "-o", output};
        
        try
        {
            app.main(args);
            
            String allOut = "";
            String allExpected = "";
        
            File file = new File(output);
            Scanner oScan = new Scanner(file);
            
            File expectedOut2 = new File(expected);
            Scanner eScan = new Scanner(expectedOut2);
            
            //Scans in output data ignoring time
            while (oScan.hasNextLine())
            {
                String curLine = oScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                allOut += curLine + "\n";
            }
            //scans in expected data ignoring time
            while (eScan.hasNextLine())
            {
                String curLine = eScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                
                allExpected += curLine + "\n";
            }
            
            assertEquals(allExpected, allOut);
        }
        catch (FileNotFoundException exception)
        {
            System.out.println("Error test file not found. (main)");
        }
        catch (Throwable exception)
        {
            System.out.println("No plugin class found.");
        }

    }
}
