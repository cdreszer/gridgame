package gridgames;

import java.util.*;
/**
 * The MyRenderable class is implemented by the plug-in author
 * so that they can create cells that contain either text or an image.
 * 
 * The cell is also represented by a symbol, whether or not it is an image.
 * 
 * @author Chase Dreszer 
 * @version Nov 2015
 */

public interface MyRenderable
{
    // The necessary start tag to display HTML text
    public static final String kStartTags = "<HTML><B>";
    // The necessary end tag to display HTML text
    public static final String kEndTags = "</B><HTML>";
    
    /**
     * Returns the text the plug-in author wants to display in a
     * cell. 
     * 
     * @return the text that should be displayed in a cell formatted as 
     *  startTags + text + endTags.
     */
    public String htmlText();
    
    /**
     * Returns whether or not the renderable cell contains an image.
     * 
     * @return whether or not the cell contains an image
     */
    public boolean isImage();
    
    /**
     * Returns the renderable's identifying symbol.
     * 
     * @return symbol as a char
     */
    public char getSymbol();
    
    /**
     * Returns the renderable's symbol or text to be displayed.
     * @return symbol
     */
    public String getText(); 
    
    /**
     * Returns a map of all the renderable token's names 
     * for the grid game mapped with the file path to their images, if anything.
     * 
     * All images paths must include the plugin package.
     *  ex. "/Collapse/GiraurdSkin/piecepurple.jpg"
     * 
     * Key = piece name
     * Value = path to image
     * 
     * @return map of piece names and images
     */
    public Map<Character, String> getRenderableImageMap();
    
}
