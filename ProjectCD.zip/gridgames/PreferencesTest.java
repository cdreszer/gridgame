package gridgames;



/**
 * The PreferencesTest class tests preferences.
 *
 * @author  Chase Dreszer
 * @version Nov 2015
 */
public class PreferencesTest extends junit.framework.TestCase
{

}
