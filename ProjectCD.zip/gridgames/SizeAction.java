package gridgames;

import javax.swing.*;
import java.awt.event.*;

/**
 * The quit action quits the grid game.
 * 
 * @author Chase Dreszer 
 * @version Nov 2015
 * 
 */
public class SizeAction extends GridAction
{
    //the game to restart
    private GridGame game;
    private int size;
    
    /**
     * The constructor for a Size Action acts the same way as the GridAction, 
     * while additionally setting the game to a particular size.
     * 
     * @param label - the name of the action to appear in the menu
     * @param icon - the icon to appear next to the name if any
     * @param mnemonic - the keyboard shortcut for the action
     * @param game - the game to perform the action on
     * @param size - the size to make the baord
     */
    public SizeAction(String label, ImageIcon icon,
                      Integer mnemonic,
                      GridGame game,
                      int size)
    {
        super(label, icon, mnemonic);
        this.game = game;
        this.size = size;
    }
    
    /**
     * Performs a restart on the grid game.
     * @param event - the action event.
     */
    public void actionPerformed(ActionEvent event) 
    {
        System.out.println("k");
        //Sets game to specified size
        game.getArea().setSize(size);
        //Creates a new game.
        game.newGame();
    }
}
