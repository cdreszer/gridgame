package gridgames;

import java.util.*;
import java.io.*;

/**
 * The HallOfFame class represents a reusable "Hall of Fame" that 
 * developers can use in their board game applications.  
 * The Hall of Fame represents a fixed length ordered list sorted 
 * by some criteria that persists between executions.  
 * 
 * The primary operation is "add" which inserts an item into the list, 
 * if it qualifies. 
 * 
 * @param <PlayerEntry> - all entries into HOF must be of type PlayerEntry
 * @author Chase Dreszer
 * @version 11.27.15
 */
public class HallOfFame<PlayerEntry> implements Serializable
{
    private static final long kSerialID = 23;
    private int size;
    private int toBeDisplayed;
    private String fileName;
    //private TreeMap<String, Object> players;
    private TreeSet<PlayerEntry> entries;

    /**
     * ...
     * 
     * If the HallOfFame constructor is passed a comparator it will be used to
     * sort the data passed in add().  If the comp paramter is passed null,
     * the data will be sorted in natural ordering.
     * 
     * @param fileName - The name of the file for the Hall of Fame to be stored in
     * @param size - The size of the persistant hall of fame
     * @param toBeDisplayed - The # of scores to be displayed
     * 
     */
    @SuppressWarnings("unchecked")
    public HallOfFame(String fileName, int size, int toBeDisplayed)
    {
        // sets instance variables
        this.fileName = fileName;

        File file = new File(fileName);

        // creates a new tree map with score object as key
        entries = new TreeSet<PlayerEntry>();   

        try 
        {
            //Checks to see if file doesn't already exist
            if (!file.exists())
            {
                file.createNewFile();

            }
            
            // Reads the serialized file
            FileInputStream in = new FileInputStream(fileName);
            ObjectInputStream inObj = new ObjectInputStream(in);
            //Fills entries with stored data
            //HallOfFame hof = (HallOfFame) inObj.readObject();
            entries = new TreeSet<PlayerEntry>(((HallOfFame<PlayerEntry>) 
                inObj.readObject()).getEntries());
            
            inObj.close();
        }
        catch (IOException exc)
        {
            System.out.println(exc);
        }
        catch (ClassNotFoundException exc)
        {
            System.out.println(exc);
        }

        this.size = size;
        this.toBeDisplayed = toBeDisplayed;

    }

    /**
     * Gets all the entries of the hall of fame.
     * @return set of all entries
     */
    public TreeSet<PlayerEntry> getEntries()
    {
        return entries;
    }

    /**
     * Clears the hall of fame.
     */
    public void clear()
    {
        try
        {
            new FileOutputStream(fileName).close();
        }
        catch (Throwable exc)
        {
            System.out.println(exc);
        }
        // creates a new tree map with score object as key
        entries = new TreeSet<PlayerEntry>();  
    }

    /**
     * The add method inserts an item into the list, if it qualifies.
     * 
     * @param entry - the entry to be added to the hall of fame
     * 
     */
    public void add(PlayerEntry entry)
    {
        int players = 0; //keeps track of how many people currently in
        
        entries.add(entry);
        
        Iterator<PlayerEntry> iterator = entries.iterator();

        //Counts the amount of players currently in map
        while (iterator.hasNext())
        {
            PlayerEntry curEntry = iterator.next();
            players++;
        }

        //Checks to see if amount of players in map is > acceptable
        if (players > size)
        {
            entries.remove(entries.first());
        }

        writeToFile();
    }

    /**
     * Writes the entire HOF to the fileName provided when constructing.
     * 
     */
    public void writeToFile()
    {
        try 
        {
            FileOutputStream out = new FileOutputStream(fileName);
            ObjectOutputStream outObj = new ObjectOutputStream(out);
            outObj.writeObject(this);
            outObj.close();
        }
        catch (IOException e)
        {
            System.out.println("IOEception: writing to a file");
        }

    }
    
    /**
     * Checks to see if the player is eligible for the Hall of Fame.
     * @param toEnter - the player to enter the HOF
     * @return whether or not the player is eligible
     */
    public boolean isEligible(PlayerEntry toEnter)
    {
        boolean eligible = false;
        
        //Checks if the HOF is full.
        if (entries.size() >= size)
        {
            PlayerEntry lowestScore = entries.first();
            
            //Checks to see if the score is better than the lowest entry
            //if (lowestScore.compareTo(toEnter) < 0)
            //{
                //eligible = true;
            //}
        }
        else
        {
            eligible = true;
        }
        
        return eligible;
    }
    
    /**
     * Returns a String with all of the hall of fame names and "scores".
     * Prints:  
     *          1  Fina     17
     *          2  Chase    11
     * @return all of the hall of famers as a String.
     */
    public String allHOF()
    {
        String allHOF = "";
        int place = 1;

        NavigableSet<PlayerEntry> orderedEntries = entries.descendingSet();
        
        Iterator<PlayerEntry> iterator = orderedEntries.iterator();
        //Runs through each entry in list in descending order
        while (iterator.hasNext())
        {
            PlayerEntry entry = iterator.next();
            //Checks to see if the amount to be displayed > acceptable
            allHOF += place++ + "  " + entry.toString() + "\n";
        }
        
        return allHOF;
    }

    /**
     * Returns a String with only the # of scores specified to be displayed
     * in the Hall of Fame.
     * Format:  
     *          1  Fina     17
     *          2  Chase    11
     * @return only the # of hall of famers specified as a String.
     */
    public String toBeDisplayed()
    {
        String displayed = "";
        int place = 1;


        NavigableSet<PlayerEntry> orderedEntries = entries.descendingSet();
        Iterator<PlayerEntry> iterator = orderedEntries.iterator();
        //Runs through each entry in list in descending order
        while (iterator.hasNext())
        {
            PlayerEntry entry = iterator.next();
            //Checks to see if the amount to be displayed > acceptable
            //allHOF += place++ + "  " + entry + "    " + entry.getAttribute() + "\n";
            if (place <= toBeDisplayed)
            {
                //Adds place, name, score to String
                displayed += place++ + "  " + entry.toString() + "\n";
            }
        }

        return displayed;
    }

    /**
     * Returns String with only the hall of famers to be displayed.
     * @return only the # of hall of famers specified as a String
     */
    public String toString()
    {
        return toBeDisplayed();
    }

}
