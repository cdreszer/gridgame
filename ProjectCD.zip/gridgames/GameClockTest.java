package gridgames;

import collapse.*;

/**
 * Test class for GameState.
 *
 * @author  Chase Dreszer
 * @version Oct 2015
 */
public class GameClockTest extends junit.framework.TestCase
{
    GridGame game = new CollapseGame();
    /**
     * Tests set time.
     */
    public void testSetTime()
    {
        /*
        PlayingArea area = new PlayingArea(5);
        GameState state = new GameState(game);
        //tests start
        String toReturn = state.getStatus();
        assertEquals("Tiles left: 9    Moves: " +
            "0  0:00", toReturn);
            
        //tests with 10 seconds
        state.setTime(10);
        toReturn = state.getStatus();
        assertEquals("Tiles left: 9    Moves: 0  0:10", toReturn);
        */
    }

    /**
     * Tests getting the status.
     */
    public void testGetStatus()
    {
        /*
        PlayingArea area = new PlayingArea(5);
        GameState state = new GameState(game);
        //tests start
        String toReturn = state.getStatus();
        assertTrue(toReturn.equals("Tiles left: 9    Moves: " +
            "0  0:00"));
            
        //tests with 10 seconds
        state.setTime(10);
        toReturn = state.getStatus();
        assertEquals("Tiles left: 9    Moves: " +
            "0  0:10", toReturn);
            
        //tests with 90 seconds
        state.setTime(90);
        //area.clearPlayingArea();
        toReturn = state.getStatus();
        assertTrue(toReturn.equals("Tiles left: 9    Moves: " +
            "0  1:30"));
            */
    }

}
