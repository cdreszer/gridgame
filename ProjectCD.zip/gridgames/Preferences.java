package gridgames;

import java.io.*;
import java.util.*;
import Collapse.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import org.ini4j.*;
import org.ini4j.Profile.Section;


/**
 * The Preferences class represents the preferences for the Grid Game.
 * Preferences are read from a preferences.ini file.
 * 
 * The menu bar constructed while reading the preferences file is
 * accesible through getMenu().
 * 
 * The console menu constructed while reading the preferences file is 
 * accessible through getPreferencesConsoleMenu().
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public class Preferences
{
    private int defaultSize;
    private JMenu menu;
    private GridGame myGame;
    private String pluginName;
    private String preferencesMenu;
    private TreeMap<String, TreeMap<String, String>> prefs;
    //private TreeMap<String, String> sectionPrefs;
    private TreeMap<String, String> curPreferences;
    //private TreeMap<Character, TreeMap<String, String>> consolePref;
    
    /**
     * Creates a new instance of Preferences.
     * @param isConfigured - whether or not the board is preconfigured.
     * @param game - the observable game
     */
    public Preferences(boolean isConfigured, GridGame game)
    {
        myGame = game;    
        curPreferences = new TreeMap<String, String>();
        //Creates Preferences menu
        menu = new JMenu("Preferences");
        preferencesMenu = "";
        prefs = new TreeMap<String, TreeMap<String, String>>();
        
        try
        {
            Wini ini = new Wini(new File(
                "../GridGameFramework/" + game.getPluginName() + "/preferences.ini"));

            //gets all the section names
            Set<String> sectionNames = ini.keySet();    
            
            JMenu submenu;
            ButtonGroup group;
            //for checking if board size
            int sectionCounter = 0;
            char curChar = 'a';
     
            //Gets all section in the ini file
            for (String sectionName : sectionNames)
            {
                int itemCounter = 0;    //counts how many options there are
                submenu = new JMenu(sectionName);
                //Adds to the console preferences menu.
                preferencesMenu += "\n[" + sectionName + "]\n";
                // creates a button group so only one can be toggled.
                group = new ButtonGroup();   
                TreeMap<String, String> sectionPrefs = new TreeMap<String, String>();
                Wini.Section section = ini.get(sectionName);
                //runs through all keys in section
                for(String option : section.keySet())
                {
                    JRadioButtonMenuItem sizeMenuItem;       
                    //adds to console menu
                    sectionPrefs.put(option, section.fetch(option));
                    
                    //adds to tree mapping
                    if (itemCounter == 0)
                    {
                        curPreferences.put(sectionName, option);
                    }
                    
                    //Checks if a board size option.
                    if (sectionCounter == 0)
                    {
                        //Creates size action for corresponding size.
                        
                        //sets default board size if not configured.
                        if (itemCounter++ == 0 && !isConfigured)
                        {
                            //Sets the default size
                            defaultSize = Integer.parseInt(section.fetch(option));
                        }   

                    }

                    sizeMenuItem = new JRadioButtonMenuItem(option);
                    preferencesMenu += "(" + curChar++ + ") " + option + " = " + 
                        section.fetch(option) + "  ";

                    addOtherListener(sizeMenuItem, sectionName, option);
                    

                    //adds option to submenu
                    group.add(sizeMenuItem);
                    submenu.add(sizeMenuItem);
                }
                sectionCounter++;
                //adds the finished submenu to preferences
                menu.add(submenu);
                prefs.put(sectionName, sectionPrefs);
            }
            
        }
        catch (IOException error)
        {
            System.out.println("No preferences file.");
        }
    }
    
    /**
     * Returns the default size of the board.
     * 
     * @return the default siz to create the game at startup.
     */
    public int getDefaultSize()
    {
        return defaultSize;
    }
    
    /**
     * Returns the Preferences menu to be added to the menu bar.
     * 
     * @return menu - the menu to be added to the menu bar.
     */
    public JMenu getMenu()
    {
        return menu;
    }
    
        
    /**
     * Adds an action listener to each each size radio button, so that
     * when the user clicks on a size it changes the playing area size.
     * 
     * @param sizeMenuItem - the menu item
     * @param size - the size to make the playing area
     */
    public void addSizeListener(JRadioButtonMenuItem sizeMenuItem, final int size)
    {
        sizeMenuItem.addActionListener(new ActionListener()
            {

                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    //Sets game to specified size
                    myGame.getArea().setSize(size);
                    //Creates a new game.
                    myGame.newGame();
                }
           
            });
    }
    
    /**
     * Adds action listener to all other Preference options.
     * Should create a new game upon click.
     * 
     * @param sizeMenuItem - the menu item
     * @param section - the section of the action
     * @param option - the option in the section
     */
    public void addOtherListener(JRadioButtonMenuItem sizeMenuItem,
        final String section, final String option)
    {
        
        sizeMenuItem.addActionListener(new ActionListener()
            {

                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    //checks if cur already
                    if (curPreferences.containsKey(section))
                    {
                        curPreferences.remove(section);
                    }
                    curPreferences.put(section, option);
                    //Creates a new game.
                    myGame.newGame();
                }
           
            });
    }
    
    /**
     * Returns the key-value map pairing for the preference menu.
     * @return key-value map of preferences
     */
    public TreeMap<String, TreeMap<String, String>> getPreferenceValues()
    {
        return prefs;
    }
    
    /**
     * Returns the key-value map pairing for currently enabled preferences.
     * @return key-value map of preferences
     */
    public TreeMap<String, String> getCurPreferences()
    {
        return curPreferences;
    }
    
    /**
     * Sets current preference for that section.
     * 
     * @param section - the section of the preference
     * @param option - option selected in section.
     */
    public void addCurPreference(String section, String option)
    {
        //checks if section already used
        if (curPreferences.containsKey(section))
        {
            curPreferences.remove(section);
        }
        
        curPreferences.put(section, option);        
    }
    
    /**
     * Returns the key-value map pairing for currently enabled preferences.
     * @return key-value map of preferences
     */
    /*
    public TreeMap<Character, TreeMap<String, String>> getConsolePreferences()
    {
        return consolePref;
    }
    */
    
    /**
     * Returns the preferences console menu.
     * @return the console menu
     */
    public String getPreferencesConsoleMenu()
    {
        return preferencesMenu + "\nYour choice?\n";
    }
}
