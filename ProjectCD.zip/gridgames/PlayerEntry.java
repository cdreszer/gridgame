package gridgames;

import java.io.*;
/**
 * PlayerEntry is a singular entry within the HOF that implements comparable
 * so that the players can be sorted in the desired order of the plug-in
 * author.
 * 
 * Each player entry has a name and an attribute to be sorted by.
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public abstract class PlayerEntry implements Comparable, Serializable
{
    /**
     * Returns the name of the player.
     * @return name of the player
     */
    public abstract String getName();
    
    /**
     * Returns the name of the player.
     * @param name - of the player
     */
    public abstract void setName(String name);     
    
    /**
     * Returns the attribute that the plug-in author wants to
     * sort the hall of fame by.
     * 
     * @return the entry's attribute as a string (score, time, etc.)
     */
    public abstract String getAttribute();

    /**
     * Returns the type of attribute that the plug-in author wants to
     * sort the hall of fame by.
     *  ex. "score", "time", etc.
     * @return the name of the attribute type
     */
    public abstract String getAttributeType();
    
    /**
     * Must override equals method.
     * @param other - object to compare to
     * @return whether or not the play entries are equal
     */
    @Override
    public abstract boolean equals(Object other);
    
    /**
     * Must implement compareTo method.
     * @param other - object to compare to
     * @return -1 if less than, 0 if equal, 1 if greater than
     */
    public abstract int compareTo(Object other);
    
    /**
     * Must implement toString method in the way that the plug-in auhtor
     * wants to display name and attribute.
     *  ex. "Chase    5" or "Chase    0:37"
     *  
     * @return how HOF entry will be displayed
     */
    public abstract String toString();

}
