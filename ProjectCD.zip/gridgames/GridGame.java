package gridgames;

import Collapse.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * The ObservableArea contains the status and playing area.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public abstract class GridGame extends Observable
{
    private PlayingArea area;
    private GameClock clock;
    private Preferences preferences;
    private boolean hasQuit;
    private boolean showHOF = false;
    private int size;
    
    /**
     * Creates a new instance of Grid game by getting the preferences
     * and default size.  Sets hasQuit to false and sets the clock to be
     * ascending from time 0:00.
     * 
     * Leaves instantiating the playing area up to the plug-in author.
     */
    public GridGame()
    {
        size = initialSize();
        //area.setSize(this.size);
        hasQuit = false;
        
        clock = new GameClock(false, 0);
        //startGame();
    }
    
    /**
     * Creates a new game by reading a predefined board 
     * configuration with which to start the game.
     * @param scan Scanner from which a board configuration is read. 
     */
    public GridGame(Scanner scan)
    {
        //Not all grid games may implement scan
    }
    
    /**
     * Configures the board given by reading a predefined board 
     * configuration with which to start the game.
     * 
     * @param myArea - playing area to be configured
     * @param scan Scanner from which a board configuration is read.
     * @return configured playing area.
     */
    public PlayingArea setGridGame(PlayingArea myArea, Scanner scan)
    {
        int row = 0;
        size = 0;
        
        String symbols = "";
        
        //Checks first line of the scanner passed
        if (scan.hasNextLine())
        {
            symbols = scan.nextLine();
            size = symbols.length();
        }
        //Sets the area to the new size.
        myArea.setSize(size);
        //Runs through columns
        for (int col = 0; col < size; col++)
        {
            myArea.setValueAt(row, col, symbols.charAt(col));
        }
        
        //Searches through rest of lines
        while (scan.hasNextLine())
        {
            //increments row
            row++;
            //stores next row
            symbols = scan.nextLine();
            
            //Runs through columns
            for (int col = 0; col < size; col++)
            {
                //sets the value at row,col to the symbol
                myArea.setValueAt(row, col, symbols.charAt(col));
            }   
        }
        
        return myArea;
    }
    
    /**
     * Gets the games Preferences.
     * @return preferences
     */
    public Preferences getPreferences()
    {
        return preferences;
    }
    
    /**
     * Returns the PlayingArea of the game.
     * @return the playing area
     */
    public abstract PlayingArea getArea();
    
    /**
     * Returns the status panel as a string to be put into "status".
     * @return a string representing the status of the game.
     */
    public abstract String getStatus();
    
    /**
     * Returns the games clock.
     * @return the game clock
     */
    public GameClock getClock()
    {
        return clock;
    }
    
    /**
     * Sets the games clock.
     * @param isDescending - whether or not the clock is descending
     * @param startingSeconds - the seconds of which to start the game clock at
     */
    public void setClock(boolean isDescending, int startingSeconds)
    {
        clock = new GameClock(isDescending, startingSeconds);
    }
    
    /**
     * Returns the size of the game.
     * @return size of the board
     */
    public abstract int getSize();
    
    /**
     * Returns the size of the board after finding the default size from Preferences.
     * @return default size
     */
    public int initialSize()
    {
        preferences = new Preferences(false, this);
        size = preferences.getDefaultSize();
        return size;
    }
    
    /**
     * Starts the game timer.
     */
    public void startGame()
    {
        clock.startTimer();
    }
    
    /**
     * Refreshes the board.
     * Useful when creating a new game, restarting, and undoing.
     */
    public void refresh()
    {
        setChanged();
        notifyObservers();
    }
    
    /**
     * Checks to see if the game is over.
     * @return whether or not the game is over
     */
    public boolean hasQuit()
    {
        return hasQuit;
    }
    
    /**
     * Sets the game to being over.
     */
    public void setHasQuit()
    {
        hasQuit = true;
    }
    
    /**
     * Creates a new game.
     */
    public abstract void newGame();
    
    /**
     * Quits the game.
     */
    public void quit()
    {
        setHasQuit();
        clock.stopTimer();
        
        refresh();
    }
    
    /**
     * Checks to see if the game has been won
     * @return whether or not the game has been won
     */
    public abstract boolean hasWon();
    
    /**
     * Carries out the game logic for the specified value being clicked.
     * @param rowIndex - row location of click
     * @param columnIndex - col location of click
     */
    public abstract void valueAtLeftClicked(int rowIndex, int columnIndex);
    
    /**
     * Carries out the game logic for the specified value being clicked.
     * @param rowIndex - row location of click
     * @param columnIndex - col location of click
     */
    public abstract void valueAtRightClicked(int rowIndex, int columnIndex);
    
    /**
     * Returns the path to the background image.
     * Returns null if no background image.
     * @return background image
     */
    public abstract String getBackgroundImagePath();
    
    /**
     * Returns a list of menu actions for the observable game.
     * @return list of menu actions
     */
    public abstract List<Action> getMenuActions();
    
    /**
     * Returns a list of preference actions for the observable game.
     * @return list of pref actions
     */
    public abstract List<Action> getPreferenceActions();
    
    /**
     * Returns the name of the plug-in.
     * Used when searching for configuration files.
     *  ex. "Collapse"
     * @return name of the plug-in
     */
    public abstract String getPluginName();
    
    /**
     * Returns the PlayerEntry to be entered into the HOF.
     * @return the HOF player entry
     */
    public abstract PlayerEntry getPlayerEntry();
    
    /**
     * Returns whether or not the Hall of Fame should be currently showed.
     */
    public void setShowHallOfFame()
    {
        showHOF = true;
        refresh();
    }
    
    /**
     * Returns whether or not the Hall of Fame should be currently showed.
     */
    public void setNoLongerShowHallOfFame()
    {
        showHOF = false;
    }
    
    
    /**
     * Returns whether or not the Hall of Fame should be currently showed.
     * @return whether or not the HOF should be shown
     */
    public boolean shouldShowHallOfFame()
    {
        return showHOF;
    }
    
    
    /**
     * Returns an instance of the HallOfFame for the current game.
     * @return HallOfFame (filename, size, how many to be displayed)
     */
    public abstract HallOfFame<PlayerEntry> getHallOfFame();
}
