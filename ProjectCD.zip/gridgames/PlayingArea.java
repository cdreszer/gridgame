package gridgames;

import Collapse.*;
import javax.swing.table.AbstractTableModel;
import java.util.*;

/**
 * The PlayingArea class represents the playing area for the Collapse game.
 * 
 * The playing area consists of two dimensional array of customizable
 * renderable cells.  The cells may contain images or text.
 * 
 * The size of the playing area is adjustable, but is always a square.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public abstract class PlayingArea extends AbstractTableModel
{
    /** Represents the the 2D area */
    private MyRenderable[][] myArea;
    private String[] columns;
    
    private int size;           //Size of the playing area.

    
    /**
     * Set columns so PlayingArea displays properly.
     * @param gameSize - size of playing area.
     */
    private void setColumns(int gameSize)
    {
        columns = new String[gameSize];
        
        //Sets all columns to ""
        for (int ndx = 0; ndx < gameSize; ndx++)
        {
            columns[ndx] = "";
        }
    }
    
    /**
     * Sets the playing area to myArea.
     * @param area - the GridGame area to set.
     */
    public void setPlayingArea(MyRenderable[][] area)
    {
        myArea = area;
    }
    
    /**
     * Returns 2D array of tiles.
     * @return my area
     */
    public MyRenderable[][] getArea()
    {
        return myArea;
    }
    
    /**
     * Sets the playing area size and restarts.
     * 
     * @param newSize - size of the new playing area
     */
    public abstract void setSize(int newSize);
        
    
    /**
     * Returns columns so number of columns will be displayed properly.
     * @return columns
     */
    public String[] getColumns()
    {
        return columns;
    }
    
    /**
     * Randomizes all the tiles in the playing area.
     * Most useful when starting a new game.
     */
    public abstract void randomizePlayingArea();
    
    /**
     * Returns the number of rows in the playing area.
     * @return num rows
     */
    @Override
    public abstract int getRowCount();

    /**
     * Returns the number of columns in the playing area.
     * @return num columns
     */
    @Override
    public abstract int getColumnCount();
   
    /**
     * Returns the value in the playing area corresponding to
     * the row index and column index.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @return object
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        return myArea[rowIndex][columnIndex];
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public abstract void valueAtLeftClicked(int rowIndex, int columnIndex);
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public abstract void valueAtRightClicked(int rowIndex, int columnIndex);
    
    /**
     * Sets the Tile in the playing area corresponding to
     * the row index and column index to the color/symbol specified.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol the tile is to be set to
     */
    public abstract void setValueAt(int rowIndex, int columnIndex, char symbol);
    
    
    /**
     * Clears the entire playing area.
     * Used when resizing playing area.
     */
    public abstract void clearPlayingArea();
    
    /**
     * Sets up all necessary conditions for the start of the game.
     */
    public abstract void setupStartingPlayingArea();

}
