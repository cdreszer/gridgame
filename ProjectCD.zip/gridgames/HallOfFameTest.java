package gridgames;
import collapse.*;
import java.sql.Time;
import java.util.*;


/**
 * The test class HallOfFameTest.
 *
 * @author  Fina Beauchamp
 * @author Chase Dreszer
 * @version 11.5.15
 */
public class HallOfFameTest extends junit.framework.TestCase
{

    /**
     * tests that only five values are displayed
     */
    public void testAdd()
    {
        CollapseEntry e1 = new CollapseEntry("Chase", 5);
        CollapseEntry e2 = new CollapseEntry("Chase", 7);
        CollapseEntry e3 = new CollapseEntry("Chase", 9);
        CollapseEntry e4 = new CollapseEntry("Chase", 11);
        CollapseEntry e5 = new CollapseEntry("Chase", 13);
        
        HallOfFame<PlayerEntry> hof = new HallOfFame<PlayerEntry>("test.txt", 5, 5);
        hof.clear();
        if (hof.getEntries().size() == 0)
        {
            hof.add(e1);
            hof.add(e2);
            hof.add(e3);
            hof.add(e4);
            hof.add(e5);
            /*
            hof.add("Chase", 13);
            hof.add("Fina", 100);
            hof.add("Sea", 120);
            hof.add("Cha", 136);
            hof.add("Fin", 1000);
            */

        }

        HallOfFame<Integer> hof2 = new HallOfFame<Integer>("test.txt", 5,5);

        assertEquals("1  Chase    5\n2  Chase    7\n3  Chase    9\n4  Chase    11\n5  Chase    13\n", hof2.toString());
        hof.clear();
        assertEquals("", hof.toString());
        
    }

    /**
     * test the clear method
     */
    public void testClear()
    {
        /*
        HallOfFame<Integer> hof = new HallOfFame<Integer>("test.txt", 5, 5);
        assertEquals(hof.toString(), "1  Fin    1000\n2  Cha    136\n3  Sea    120\n4  Fina    100\n5  Chase    13\n");
        hof.clear();
        assertEquals(hof.toString(), "");
        */
    }

    /**
     * test that the comparator is working 
     */
    public void testComparator()
    {
        /*
        HallOfFame<Integer> hof3 = new HallOfFame<Integer>("test2.txt", 5, 5);

        hof3.clear();
        if( hof3.getScores().size() == 0)
        {
            hof3.add("Sean", 12);
            hof3.add("Chase", 13);
        }

        assertEquals(hof3.toString(), "1  Chase    13\n2  Sean    12\n");
        */
    }

    /**
     * tests Hall Of Fame with time values
     */
    public void testTime()
    {
        /*
        HallOfFame<Time> time = new HallOfFame<Time>("testTime.txt", 5, 3);
        time.clear();
        if(time.getScores().size() == 0)
        {

            time.add("Sean", new Time(6000));
            time.add("Chase", new Time(5000));
        }

        assertEquals(time.toString(), "1  Sean    16:00:06\n2  Chase    16:00:05\n");
        */
    }

    /**
     * tests Hall Of Fame with time values
     */
    public void testTime2()
    {
        /*
        HallOfFame<Time> time = new HallOfFame<Time>("testTime2.txt", 5, 3);
        time.clear();
        if(time.getScores().size() == 0)
        {

            time.add("Sean", new Time(6000));
            time.add("Chase", new Time(5000));
        }

        assertEquals(time.toString(), "1  Sean    16:00:06\n2  Chase    16:00:05\n");
        */
    }
    
    /**
     * test that only 3 values are displayed
     */
    public void testToBeDisplayed()
    {
        /*
        HallOfFame<Integer> hof = new HallOfFame<Integer>("test3.txt", 5, 3);
        hof.clear();
        if (hof.getScores().size() == 0)
        {
            hof.add("Sean", 12);
            hof.add("Chase", 13);
            hof.add("Fina", 100);
            hof.add("Sea", 120);
            hof.add("Cha", 136);
            hof.add("Fin", 1000);

        }

        HallOfFame<Integer> hof2 = new HallOfFame<Integer>("test3.txt", 5,3);

        assertEquals(hof2.toString(), "1  Fin    1000\n2  Cha    136\n3  Sea    120\n");
    */
    }
    

}
