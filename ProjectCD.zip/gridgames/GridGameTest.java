package gridgames;



/**
 * The class ObservableGameTest tests ObservableGame.
 *
 * @author  Chase Dreszer
 * @version Nov 2015
 */
public class GridGameTest extends junit.framework.TestCase
{

}
