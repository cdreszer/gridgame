package gridgames;

import javax.swing.table.*;
import javax.swing.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.util.*;

/**
 * A cell renderer for the cells on the game board.
 * Assigns the correct Tile image if any are applicable.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class CellRenderer extends DefaultTableCellRenderer
{
    //Name of the plugin using the framework
    //private String pluginName;
    //Size of the font that text will be displayed in cell
    private final int kFontSize = 30;
    
    /** 
     * Construct a CellRenderer that will use the images specified. 
     */
    public CellRenderer()    
    { 
        super();
    }

    /** Set the value to be displayed in the JTable for the given cell. 
     * @param cell a Piece instance
     */
    @Override
    public void setValue(Object cell)
    {
        setHorizontalAlignment(CENTER);
        setIcon(null);
        setText(null); // default case
        // Error check for null cells
        if (cell != null)
        {
            //Creates a MyRenderable from the cell
            MyRenderable renderable = (MyRenderable) cell;
            
            //Accesses image map for the renderable
            Map<Character, String> imageMap = renderable.getRenderableImageMap();
            //Gets the symbol from the renderable.
            Character symbol = renderable.getSymbol();
            //Checks to see if the renderable is an image.
            if (renderable.isImage())
            {
                // Checks if the symbol is within the image map
                if (imageMap.containsKey(symbol))
                {
                    //Sets renderable to the appropriate image
                    setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage(
                        this.getClass().getResource(
                            "../" + imageMap.get((symbol))))));   
                }
                else
                {
                    cell = null;
                }
            }
            //Sets the text of the renderable
            else
            {
                setFont(new Font("Serif", Font.BOLD, kFontSize));
                setText(renderable.htmlText());
            }
        }
    } // end setValue

}
