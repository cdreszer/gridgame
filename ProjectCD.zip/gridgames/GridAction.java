package gridgames;

import javax.swing.*;
import java.awt.event.*;

/**
 * The GridAction class allows for plug-in authors to create grid actions by
 * extending this abstarct class and implementing the actionPerformed method.
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public abstract class GridAction extends AbstractAction
{
    /**
     * The constructor for a GridAction allows for the author to assign a label
     * to the action, an icon for the action, and an accelerator for the action.
     * 
     * @param label - the name of the action to appear in the menu
     * @param icon - the icon to appear next to the name if any
     * @param mnemonic - the keyboard shortcut for the action
     */
    public GridAction(String label, ImageIcon icon,
                      Integer mnemonic)
    {
        super(label, icon);
        //makes sure mnemonic isn't null
        if (mnemonic != null)
        {
            KeyStroke accelerator = KeyStroke.getKeyStroke(mnemonic, 
                ActionEvent.ALT_MASK);
            putValue(MNEMONIC_KEY, mnemonic);
            putValue(ACCELERATOR_KEY, accelerator);
        }
        
        putValue(ACTION_COMMAND_KEY, label.toLowerCase());
        
        
    }
    
    /**
     * The actionPerformed method performs the appropriate action for the 
     * plug-in grid game.
     * @param event - the action event
     */
    public abstract void actionPerformed(ActionEvent event);
}
