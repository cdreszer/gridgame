package gridgames;

import collapse.*;

/**
 * The test class PlayingAreaTest.
 *
 * @author  Chase Dreszer
 * @version Oct 2015
 */
public class PlayingAreaTest extends junit.framework.TestCase
{
    private CollapsePlayingArea area;
    /**
     * Default constructor for test class PlayingAreaTest
     */
    public PlayingAreaTest()
    {
    }
    
    /**
     * Tests get row count.
     */
    public void testGetRowCount()
    {
        area = new CollapsePlayingArea(3);
        assertEquals(area.getRowCount(), 3);
        area = new CollapsePlayingArea(3);
        assertEquals(area.getRowCount(), 3);
    }  
    
    /**
     * Tests get column count.
     */
    public void testGetColumnCount()
    {
        area = new CollapsePlayingArea(3);
        assertEquals(area.getColumnCount(), 3);
        area = new CollapsePlayingArea(3);
        assertEquals(area.getColumnCount(), 3);
    }
    
    /**
     * Tests get columns.
     */
    public void testGetColumns()
    {
        area = new CollapsePlayingArea(5);
        
        String[] cols = area.getColumns();
        
        //runs through all columns
        for (int col = 0; col < 5; col++)
        {
            assertTrue(cols[col].equals(""));
        }
    }
    
        
    /**
     * Tests setColumns.
     */
    public void testSetColumns()
    {
        area = new CollapsePlayingArea(1);
        
        area.setSize(7);
        String[] cols = area.getColumns();

        //runs through all columns
        for (int col = 0; col < 7; col++)
        {
            assertTrue(cols[col].equals(""));
        }
    }
    
    /**
     * tests set size
     */
    public void testSetSize()
    {
        Tile tile;
        area = new CollapsePlayingArea(2);
        
        area.setSize(3);
        
        //Runs through each row of the playing area
        for (int row = 0; row < 3; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 3; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertTrue(tile.getSymbol() == 'x' ||
                    tile.getSymbol() == 'o' || tile.getSymbol() == '+');
            }
        }
        
        area.setSize(5);
        
        //Runs through each row of the playing area
        for (int row = 0; row < 5; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 5; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertTrue(tile.getSymbol() == 'x' ||
                    tile.getSymbol() == 'o' || tile.getSymbol() == '+');
            }
        }
        
        String[] cols = area.getColumns();

        //runs through all columns
        for (int col = 0; col < 5; col++)
        {
            assertTrue(cols[col].equals(""));
        }
        
    }
    
    /**
     * Tests randomizing playing area to be filled with tiles, 
     * with no null spots.
     */
    public void testRandomizePlayingArea()
    {
        Tile tile;
        area = new CollapsePlayingArea(3);
        //Runs through each row of the playing area
        for (int row = 0; row < 3; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 3; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertTrue(tile.getSymbol() == 'x' ||
                    tile.getSymbol() == 'o' || tile.getSymbol() == '+');
            }
        }
        
        area.valueAtLeftClicked(1, 1);
        
        area.randomizePlayingArea();
        
        //Runs through each row of the playing area
        for (int row = 0; row < 3; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 3; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertTrue(tile.getSymbol() == 'x' ||
                    tile.getSymbol() == 'o' || tile.getSymbol() == '+');
            }
        }
        
    }
    
    /**
     * Tests check neighbors my building a known playing area and checking
     * if tile is now null, if it should be.
     */
    public void testValueAtClicked()
    {
        Tile tile;
        
        //building playing area
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'x');
        area.setValueAt(1, 1, 'x');
        area.setValueAt(1, 2, 'x');
        area.setValueAt(2, 0, 'x');
        area.setValueAt(2, 1, 'x');
        area.setValueAt(2, 2, 'x');
        
        //ensuring values aren't null before
        tile = (Tile) area.getValueAt(1, 0);
        assertTrue(tile != null);
        
        //Clicking in middle.
        area.valueAtLeftClicked(1, 1);
        
        //Runs through each row of the playing area
        for (int row = 0; row < 3; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 3; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertTrue(tile.getSymbol() == ' ');
            }
        }
    }
    
    /**
     * Tests getting and setting values in playing area.
     */
    public void testGetValueAt()
    {
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        Tile tile = (Tile) area.getValueAt(0, 0);
        assertEquals(tile.getSymbol(), 'x');
        
        area.setValueAt(0, 0, '+');
        tile = (Tile) area.getValueAt(0, 0);
        assertEquals(tile.getSymbol(), '+');
    }
    
    /**
     * Tests setting a spot on the playing area to a specified tile.
     */
    public void testSetValueAt()
    {
        area = new CollapsePlayingArea(3);
        Tile tile = (Tile) area.getValueAt(0, 0);
        assertFalse(tile.getSymbol() == ' ');
        area.setValueAt(0, 0, ' ');
        tile = (Tile) area.getValueAt(0, 0);
        assertTrue(tile.getSymbol() == ' ');
        
        area.setValueAt(0, 0, '+');
        tile = (Tile) area.getValueAt(0, 0);
        assertEquals(tile.getSymbol(), '+');
    }
    
    /**
     * Tests setting restart to current area.
     */
    public void testSetRestart()
    {
        
        Tile tile;
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        area.setRestart();
        area.valueAtLeftClicked(0, 1);
        

        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == ' ');
        }
        
        area.restartArea();
        
        assertTrue(area.getMoveCount() == 0);
        assertTrue(area.getTileCount() == 9);
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == 'x');
        }
        
        area.valueAtLeftClicked(0, 1);
        area.valueAtLeftClicked(1, 1);
        
        area.restartArea();
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == 'x');
        }
        
        
    }

    
    /**
     * Tests restarting the area.
     */
    public void testRestartArea()
    {
        Tile tile;
        
        //building playing area
        area = new CollapsePlayingArea(3);
        char pre1 = ((Tile)area.getValueAt(0, 0)).getSymbol();
        char pre2 = ((Tile)area.getValueAt(0, 1)).getSymbol();
        char pre3 = ((Tile)area.getValueAt(0, 2)).getSymbol();
        char pre4 = ((Tile)area.getValueAt(1, 0)).getSymbol();
        char pre5 = ((Tile)area.getValueAt(1, 1)).getSymbol();
        char pre6 = ((Tile)area.getValueAt(1, 2)).getSymbol();
        char pre7 = ((Tile)area.getValueAt(2, 0)).getSymbol();
        char pre8 = ((Tile)area.getValueAt(2, 1)).getSymbol();
        char pre9 = ((Tile)area.getValueAt(2, 2)).getSymbol();
        
        area.clearPlayingArea();
        
        area.restartArea();
        
        char post1 = ((Tile)area.getValueAt(0, 0)).getSymbol();
        char post2 = ((Tile)area.getValueAt(0, 1)).getSymbol();
        char post3 = ((Tile)area.getValueAt(0, 2)).getSymbol();
        char post4 = ((Tile)area.getValueAt(1, 0)).getSymbol();
        char post5 = ((Tile)area.getValueAt(1, 1)).getSymbol();
        char post6 = ((Tile)area.getValueAt(1, 2)).getSymbol();
        char post7 = ((Tile)area.getValueAt(2, 0)).getSymbol();
        char post8 = ((Tile)area.getValueAt(2, 1)).getSymbol();
        char post9 = ((Tile)area.getValueAt(2, 2)).getSymbol();
        
        assertEquals(pre1, post1);
        assertEquals(pre2, post2);
        assertEquals(pre3, post3);
        assertEquals(pre4, post4);
        assertEquals(pre5, post5);
        assertEquals(pre6, post6);
        assertEquals(pre7, post7);
        assertEquals(pre8, post8);
        assertEquals(pre9, post9); 
    }
    
    /**
     * Tests if the board can be undo'd.
     */
    public void testCanUndo()
    {
        Tile tile;
        
        //building playing area
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'x');
        area.setValueAt(1, 1, 'x');
        area.setValueAt(1, 2, 'x');
        area.setValueAt(2, 0, 'x');
        area.setValueAt(2, 1, 'x');
        area.setValueAt(2, 2, 'x');
        
        assertFalse(area.canUndo());
        area.valueAtLeftClicked(1, 1);
        assertTrue(area.canUndo());
    }
    
    /**
     * Tests undoing a move.
     */
    public void testUndoArea()
    {
        Tile tile;
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        assertEquals(area.getMoveCount(), 0);
        
        area.valueAtLeftClicked(0, 1);
        
        assertEquals(area.getMoveCount(), 1);

        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == ' ');
        }
        
        if (area.canUndo())
        {
            area.undoArea();
        }
        
        assertEquals(area.getMoveCount(), 2);
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == 'x');
        }
        
        area.valueAtLeftClicked(0, 1);
        
        assertEquals(area.getMoveCount(), 3);
        
        area.valueAtLeftClicked(1, 1);
        
        assertEquals(area.getMoveCount(), 4);
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(1, col);
            assertTrue(tile.getSymbol() == ' ');
        }
        
        if (area.canUndo())
        {
            area.undoArea();
        }
        
        assertEquals(area.getMoveCount(), 5);
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == ' ');
        }
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(1, col);
            assertTrue(tile.getSymbol() == 'o');
        }
        
        if (area.canUndo())
        {
            area.undoArea();
        }
        
        assertEquals(area.getMoveCount(), 6);
        
        //Runs through each column of the playing area
        for (int col = 0; col < 3; col++)
        {
            //Checking if every tile is set to null (should be)
            tile = (Tile) area.getValueAt(0, col);
            assertTrue(tile.getSymbol() == 'x');
        }
        
        if (area.canUndo())
        {
            area.undoArea();
        }
        
        assertEquals(area.getMoveCount(), 6);

    }
    
    /**
     * Tests returning the tiles remaining in the playing area.
     */
    public void testGetTileCount()
    {
       
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'x');
        area.setValueAt(1, 1, 'x');
        area.setValueAt(1, 2, 'x');
        area.setValueAt(2, 0, 'x');
        area.setValueAt(2, 1, 'x');
        area.setValueAt(2, 2, 'x');
        
        assertTrue(area.getTileCount() == 9);
        
        //Clicking in middle.
        area.valueAtLeftClicked(1, 1);
        
        assertTrue(area.getTileCount() == 0);       
    }
    
    /**
     * Tests returning amount of moves taken place in the game.
     */
    public void testGetMoveCount()
    {
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        assertTrue(area.getMoveCount() == 0);
        
        area.valueAtLeftClicked(0, 1);
        assertTrue(area.getMoveCount() == 1);
        
        area.valueAtLeftClicked(1, 1);
        assertTrue(area.getMoveCount() == 2);
        
        area.valueAtLeftClicked(2, 1);
        assertTrue(area.getMoveCount() == 3);
    }
    
    /**
     * tests clear playing area
     */
    public void testClearCollapsePlayingArea()
    {
        Tile tile;
        area = new CollapsePlayingArea(3);
        
        //Runs through each row of the playing area
        for (int row = 0; row < 3; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 3; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertFalse(tile == null);
            }
        }
        
        area.clearPlayingArea();
        //Runs through each row of the playing area
        for (int row = 0; row < 3; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 3; col++)
            {
                //Checking if every tile is set to null (should be)
                tile = (Tile) area.getValueAt(row, col);
                assertTrue(tile.getSymbol() == ' ');
            }
        }
    }

}
