package gridgames;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The GameClock class keeps track of and updates the game clock for a GridGame.
 * The GameClcok can be initalized as either ascedning or descending
 * and can be specified to have a start time (most likely for descending timers).
 * 
 * The GameClock is printed in the format: 
 *  Minutes:Seconds
 *  
 * Hours are not implemented into the game 
 * 
 * @author Chase Dreszer
 * @version Nov 2015
 */
public class GameClock extends Observable
{
    private int startTimeInSeconds;
    private boolean isCountingDown;
    private int seconds;               //Seconds since start
    private javax.swing.Timer gameClock; 
    
    private final static int kSecsInMin = 60;
    private final static int kNonSingleDigit = 10;
    
    /**
     * Constructor for the GameClock, sets the clock to be either counting up
     * or counting down from a given start time.
     * 
     * @param isCountingDown - checks to see if the clock is counting down
     * @param startTime - if counting down, provides a startTime.
     */
    public GameClock(boolean isCountingDown, int startTime)
    {
        this.isCountingDown = isCountingDown;
        startTimeInSeconds = startTime;
        
        //Checks to see if is countingDown
        if (this.isCountingDown)
        {
            seconds = startTimeInSeconds;
        }
        else
        {
            seconds = 0;
        }
    }
    
    /**
     * Starts the timer of the game, incrementing or decrementing 
     * at one second intervals. 
     */
    public void startTimer()
    {
        //Time delay for incrementing timer
        final int kTimeDelay = 1000;  
        //Creates a action listener that increments the game clock
        ActionListener incrementTime = new ActionListener() {
            public void actionPerformed(ActionEvent evt) 
            {
                //Checks to see if isCountingDown
                if (!isCountingDown)
                {
                    //increments time going up
                    seconds++;
                }
                //Makes sure that time never goes negative
                else if (isCountingDown && seconds > 0)
                {
                    seconds--;
                }
                setChanged();
                notifyObservers(seconds);
            }
        };
        gameClock = new javax.swing.Timer(kTimeDelay, incrementTime);
        
        gameClock.setInitialDelay(0);
        gameClock.start();
    }
    
    /**
     * Stops game clock.
     */
    public void stopTimer()
    {
        gameClock.stop();
    }
    
    /**
     * Resets the timer back to 0 seconds or starting time specified.
     */
    public void resetTimer()
    {
        //Checks to see if isCountingDown
        if (!isCountingDown)
        {
            seconds = 0;
        }
        else
        {
            seconds = startTimeInSeconds;
        }
        
        gameClock.start();
    }
    
    /**
     * Sets the clock to the amount of seconds given.
     * @param time - seconds into the game the clock should be set to
     */
    public void setTime(int time)
    {
        seconds = time;
    }
    
    /**
     * Returns the time as a string in the form of minutes:seconds.
     *  ex. 1:04
     *  
     *  @return the current game time
     */
    public String getTime()
    {
        String time = "";
        
        //checks if seconds under 10 seconds
        if (seconds % kSecsInMin < kNonSingleDigit)
        {
            time += seconds / kSecsInMin + ":0" + seconds % kSecsInMin;
        }
        else
        {
            time += seconds / kSecsInMin + ":" + seconds % kSecsInMin;
        }
        
        return time;
    }

}
