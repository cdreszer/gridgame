package hurkle;

import gridgames.*;
import javax.swing.table.AbstractTableModel;
import java.util.*;

/**
 * The PlayingArea class represents the playing area for the Collapse game.
 * 
 * The playing area consists of a pattern of colored rectangular tiles. 
 * When the game starts the playing area is covered with 64 tiles 
 * in a 9 by 9 grid. 
 * 
 * The size of the playing area is adjustable, but is always a square.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class HurklePlayingArea extends PlayingArea
{
    /** Represents the the 2D area */
    private HurklePiece[][] myArea;
    private String[] columns;
    // saves original format of area
    
    //private GameState state = new GameState();
    //private MinesweeperLogic logic;
    
    private int size;           //Size of the playing area.
    private int guessCount;
    private int hideRow; 
    private int hideCol;
    private final int kCheatRow = 4;
    private final int kCheatCol = 4;
    private char guess = '0';
    boolean found = false;
    private String hint;

    private int guessLimit = 5;
    private final static int kSize = 9;
    private final int kAsciiZero = 48;
    
    /**
     * Constructs a playing area of the specified size.
     * @param size - size of the playing area
     */
    public HurklePlayingArea(int size)
    {
        //sets size of area to specified size
        this.size = kSize;
        
        //sets tile and move count
        guessCount = 0;
        
        //instantiates playing area
        myArea = new HurklePiece[kSize][kSize];
        //myArea = new Tile[size][size];
        
        setColumns(size);

        //System.out.println(myArea.length + "x" + myArea[0].length);
    }
    
    /**
     * Set columns so PlayingArea displays properly.
     * @param gameSize - size of playing area.
     */
    private void setColumns(int gameSize)
    {
        columns = new String[gameSize];
        
        //Sets all columns to ""
        for (int ndx = 0; ndx < gameSize; ndx++)
        {
            columns[ndx] = "";
        }
    }
    
    /**
     * Sets the playing area size and restarts.
     * 
     * @param newSize - size of the new playing area
     */
    public void setSize(int newSize)
    {
        this.size = kSize;
        randomizePlayingArea();
    }
    
    
    /**
     * Returns columns so number of columns will be displayed properly.
     * @return columns
     */
    public String[] getColumns()
    {
        return columns;
    }
        
    /**
     * Returns 2D array of tiles.
     * @return my area
     */
    public MyRenderable[][] getArea()
    {
        return myArea;
    }
    
    /**
     * Randomizes all the tiles in the playing area.
     * Most useful when starting a new game.
     */
    public void randomizePlayingArea()
    {
        guessCount = 0;

        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                myArea[row][col] = new HurklePiece();
                //Saves restartable area
                //restartableArea[row][col] = new Square();
            }
        }
        
        hideRow = (int) (Math.random() * size);
        hideCol = (int) (Math.random() * size);
            
        myArea[hideRow][hideCol] = new HurklePiece('H');
        
        //logic = new MinesweeperLogic(myArea, size);
        
        this.fireTableChanged(null);
        
    }
    
    /**
     * Returns the number of rows in the playing area.
     * @return num rows
     */
    @Override
    public int getRowCount() 
    {
        // Since the playing area is a square, num rows = size
        return size;
    }

    /**
     * Returns the number of columns in the playing area.
     * @return num columns
     */
    @Override
    public int getColumnCount() 
    {
        // Since the playing area is a square, num columns = size
        return size;
    }
   
    /**
     * Returns the value in the playing area corresponding to
     * the row index and column index.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @return object
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        return myArea[rowIndex][columnIndex];
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param row - row index
     * @param col - column index
     */
    public void valueAtLeftClicked(int row, int col) 
    {
                // Does guess match hiding spot?
        if (row == hideRow && col == hideCol)
        {
            found = true; // found hurkle
        }
        else            
        {
            // increment count of wrong guesses
            guessCount = guessCount + 1;
            guess++;
            // Record the piece as guessed
            myArea[row][col] = new HurklePiece(guess);
            // Generate a hint message
            hint = "";
            if(row < hideRow)
            {
                hint = "SOUTH";
            } else if (row > hideRow) 
            {
                hint = "NORTH";
            }

            if(col < hideCol )
            {
                hint += "EAST";
            } else if (col > hideCol) 
            {
                hint += "WEST";
            }
        }
        fireTableDataChanged();
        
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void valueAtRightClicked(int rowIndex, int columnIndex) 
    {
        guessCount++;
        guess++;

        //Checks to see if clicked on hidden spot.
        if (myArea[rowIndex][columnIndex].isHidden())
        {
            myArea[rowIndex][columnIndex].unhide();
            //checks if was empty
            if (myArea[rowIndex][columnIndex].getSymbol() != 'H')
            {
                myArea[rowIndex][columnIndex] = 
                    new HurklePiece(guess);
            }
        }
        
        fireTableDataChanged();
    }
    
    /**
     * Sets the Tile in the playing area corresponding to
     * the row index and column index to the color/symbol specified.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol the tile is to be set to
     */
    public void setValueAt(int rowIndex, int columnIndex, char symbol)
    {
        //Sets value to the symbol passed
        myArea[rowIndex][columnIndex] = new HurklePiece(symbol);
        
        fireTableDataChanged();
    }
        
    
    /**
     * Returns the amount of moves that have been done in the playing area.
     * @return tile count
     */
    public int getGuessCount()
    {
        return guessCount;
    }
    
    /**
     * Clears the entire playing area.
     * Used when resizing playing area.
     */
    public void clearPlayingArea()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //sets tile to empty
                myArea[row][col] = new HurklePiece(' ');
            }
        }
    }
    
    /**
     * To facilitate testing, there is a Cheat function that clears 
     * the entire game board except for two tiles in the upper left 
     * corner (but doesn't win the game).  The left-most tile hides a 
     * bomb, and the right-most tile hides a "1".  If the user clicks 
     * on the right-most tile, the square is revealed and they win.  
     * (Clicking on the bomb loses the game as expected). If the user 
     * cheats and wins (or loses) and then clicks cheat again, the tiles
     * show up again. 
     * 
     */
    public void cheat()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Clears the rest of the playing area
                myArea[row][col] = new HurklePiece(' ');
            }
        }
        
        //sets the upper left corner to B and 1
        myArea[kCheatRow][kCheatCol] = new HurklePiece('H');

        
        this.fireTableChanged(null);
        
    }
    
    /**
     * Checks to see if the user has lost the game.
     * @return whether the game has been lost
     */
    public boolean hasLost()
    {
        return guessCount >= guessLimit;
    }
    
    /**
     * Checks to see if the user has lost the game.
     * @return whether the game has been lost
     */
    public boolean hasWon()
    {
        return found;
    }
    
    public String getHint()
    {
        return hint;
    }
    
    public void setGuessLimit(int numGuesses)
    {
        guessLimit = numGuesses;
    }
    
    /**
     * Checks to see if all hidden squares remaining are bombs.
     * If so returns playable as false.
     * @return whether the game is still playable
     */
    public boolean hasPlayableMove()
    {
        return !hasLost() && !found;
    }
    
    /**
     * Sets up the starting playing area.
     */
    public void setupStartingPlayingArea()
    {
        myArea = new HurklePiece[kSize][kSize];
        super.setPlayingArea(myArea);
    }
}
