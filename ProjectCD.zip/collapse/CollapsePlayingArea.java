package collapse;

import gridgames.*;
import javax.swing.table.AbstractTableModel;
import java.util.*;

/**
 * The PlayingArea class represents the playing area for the Collapse game.
 * 
 * The playing area consists of a pattern of colored rectangular tiles. 
 * When the game starts the playing area is covered with 64 tiles 
 * in a 8 by 8 grid. 
 * The size of the playing area is adjustable, but is always a square.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class CollapsePlayingArea extends PlayingArea
{
    /** Represents the the 2D area */
    private MyRenderable[][] myArea;
    private String[] columns;
    // saves original format of area
    private MyRenderable[][] restartableArea;
    //saves format of area before each move
    private Stack<MyRenderable[][]> undoArea; 
    
    //private GameState state = new GameState();
    private CollapseLogic logic;
    
    private int size;           //Size of the playing area.
    private int tileCount;      // Tiles remaining 
    private int moveCount;      // Number of clicks.
    private final static int kDefaultSize = 3;
    private final static int kMaxSize = 12;
    
    /**
     * Constructs a playing area of the specified size.
     * @param size - size of the playing area
     */
    public CollapsePlayingArea(int size)
    {
        //sets size of area to specified size
        this.size = size;
        
        undoArea = new Stack<MyRenderable[][]>(); 
        
        //sets tile and move count
        tileCount = size * size;
        moveCount = 0;
        
        //instantiates playing area
        myArea = new Tile[kMaxSize][kMaxSize];
        //myArea = new Tile[size][size];
        
        setColumns(size);
        restartableArea = new Tile[kMaxSize][kMaxSize];

        setSize(size);
        super.setPlayingArea(myArea);
        //System.out.println(myArea.length + "x" + myArea[0].length);
    }
    
    /**
     * Set columns so PlayingArea displays properly.
     * @param gameSize - size of playing area.
     */
    private void setColumns(int gameSize)
    {
        columns = new String[gameSize];
        
        //Sets all columns to ""
        for (int ndx = 0; ndx < gameSize; ndx++)
        {
            columns[ndx] = "";
        }
    }
    
    /**
     * Sets the playing area size and restarts.
     * 
     * @param newSize - size of the new playing area
     */
    public void setSize(int newSize)
    {
        clearPlayingArea();
        //sets size to new size passed
        this.size = newSize;
        
        //Sets new dimensions
        myArea = new Tile[size][size];
        restartableArea = new Tile[size][size];

        super.fireTableChanged(null);
        
        //System.out.println(myArea.length + "x" + myArea[0].length);
        //sets columns to match
        setColumns(size);
        
        //randomizes the area
        //updates the JTable
        super.fireTableStructureChanged();
        
        randomizePlayingArea();
        
    }
    
    /**
     * Returns columns so number of columns will be displayed properly.
     * @return columns
     */
    public String[] getColumns()
    {
        return columns;
    }
        
    /**
     * Returns 2D array of tiles.
     * @return my area
     */
    public MyRenderable[][] getArea()
    {
        return myArea;
    }
    
    /**
     * Randomizes all the tiles in the playing area.
     * Most useful when starting a new game.
     */
    public void randomizePlayingArea()
    {
        tileCount = size * size;
        moveCount = 0;
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //instantiates each tile in the playing area.
                myArea[row][col] = new Tile();
                //Saves restartable area
                restartableArea[row][col] = myArea[row][col];
            }
        }
        
        this.fireTableChanged(null);
        
        //Makes sure no undoable moves to begin
        while (!undoArea.isEmpty())
        {
            undoArea.pop();
        }
    }
    
    /**
     * Returns the number of rows in the playing area.
     * @return num rows
     */
    @Override
    public int getRowCount() 
    {
        // Since the playing area is a square, num rows = size
        return size;
    }

    /**
     * Returns the number of columns in the playing area.
     * @return num columns
     */
    @Override
    public int getColumnCount() 
    {
        // Since the playing area is a square, num columns = size
        return size;
    }
   
    /**
     * Returns the value in the playing area corresponding to
     * the row index and column index.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @return object
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        return myArea[rowIndex][columnIndex];
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void valueAtLeftClicked(int rowIndex, int columnIndex) 
    {
        moveCount++;
        logic = new CollapseLogic(myArea, size);
        
        MyRenderable[][] undo = new Tile[size][size];
        //fireTableCellUpdated(rowIndex, columnIndex);
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //instantiates each tile in the playing area.
                undo[row][col] = myArea[row][col];
            }
        }
        undoArea.push(undo);
        
        myArea = logic.doLeftMove(rowIndex, columnIndex);
        tileCount -= logic.amountOfDisappearedTiles();
        
        fireTableDataChanged();
        
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void valueAtRightClicked(int rowIndex, int columnIndex) 
    {
    }
    
    /**
     * Sets the Tile in the playing area corresponding to
     * the row index and column index to the color/symbol specified.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol the tile is to be set to
     */
    public void setValueAt(int rowIndex, int columnIndex, char symbol)
    {
        //Sets value to the symbol passed
        myArea[rowIndex][columnIndex] = new Tile(symbol);
        
        fireTableDataChanged();
    }
    
    /**
     * Sets current playingArea to restart.
     * Used during configured boards.
     */
    public void setRestart()
    {
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Saves restartable area
                restartableArea[row][col] = myArea[row][col];
            }
        }
        
        //Makes sure no undoable moves to begin
        while (!undoArea.isEmpty())
        {
            undoArea.pop();
        } 
    }
        
    /**
     * Restarts the playing area to it's original form.
     */
    public void restartArea()
    {
        tileCount = size * size;
        undoArea = new Stack<MyRenderable[][]>();
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //instantiates each tile in the playing area.
                setValueAt(row, col, restartableArea[row][col].getSymbol());
            }
        }
        
        //Empties undoable moves
        while (!undoArea.isEmpty())
        {
            undoArea.pop();
        }
        
        moveCount = 0;
      
    }
    
    /**
     * Checks if there are any undoable moves.
     * @return whether or not there are any moves
     */
    public boolean canUndo()
    {
        return !undoArea.isEmpty();
    }
    
    /**
     * Resets the playing area to it's form before the last click.
     * Only can undo if there was a previous move.
     * @pre canUndo() == true
     */
    public void undoArea()
    {
        //myArea = state.undoArea(myArea);
        moveCount++;
        //makes sure stack of undoable moves isn't empty
        if (!undoArea.isEmpty())
        {
            MyRenderable[][] area = undoArea.pop();
            tileCount = 0;
            //Runs through each row of the playing area
            for (int row = 0; row < size; row++)
            {
                //Runs through each column of the playing area
                for (int col = 0; col < size; col++)
                {
                    //Makes sure undo spot isn't null
                    if (area[row][col].getSymbol() != ' ')
                    {
                        tileCount++;
                        //resets tile to what it was a move before
                        setValueAt(row, col, area[row][col].getSymbol());
                    }
                    else
                    {
                        //makes tile empty
                        setValueAt(row, col, ' ');
                    }
                }
            }
        }     
        
    }
       
    /**
     * Returns the amount of tiles left in the playing area.
     * @return tile count
     */
    public int getTileCount()
    {
        return tileCount;
    }
    
    /**
     * Returns the amount of moves that have been done in the playing area.
     * @return tile count
     */
    public int getMoveCount()
    {
        return moveCount;
    }
    
    /**
     * Clears the entire playing area.
     * Used when resizing playing area.
     */
    public void clearPlayingArea()
    {
        tileCount = 0;
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //sets tile to empty
                myArea[row][col] = new Tile(' ');
            }
        }
    }
    
    /**
     * Sets up the starting playing area of the board.
     */
    public void setupStartingPlayingArea()
    {
        myArea = new Tile[kMaxSize][kMaxSize];
        super.setPlayingArea(myArea);
    }

}
