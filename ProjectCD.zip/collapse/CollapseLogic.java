package collapse;

import gridgames.*;

/**
 * The CollapseLogic class performs the collapsing of the PLayingArea,
 * whether down or towards the middle.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class CollapseLogic 
{
    /** Playing area to use collapse logic on*/
    private Tile[][] myArea;
    private int size;           //size of playing area
    //private GameState state;
    private int disappearedTiles = 0;
    
    /**
     * Specifies the direction. Used when searching neighboring tiles.
     */
    public enum Direction
    {
        UP, DOWN, LEFT, RIGHT
    }

    /**
     * Constructor for objects of class CollapseLogic
     * @param myArea - playing are to be used
     * @param size - size of playing area
     */
    public CollapseLogic(MyRenderable[][] myArea, int size)
    {
        this.myArea = (Tile[][]) myArea;
        this.size = size;       
    }
    
    /**
     * Returns amount of tiles that disappeared during turn.
     * @return disappeared tiles
     */
    public int amountOfDisappearedTiles()
    {
        return disappearedTiles;
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row of click
     * @param columnIndex - col of click
     * @return updated playing area
     */
    public Tile[][] doLeftMove(int rowIndex, int columnIndex)
    {
        //Checks neighbors of spot of click
        checkNeighbors(rowIndex, columnIndex);
        disappearedTiles = 0;
        
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Checks if tile should disappear
                if (myArea[row][col].willDisappear())
                {
                    myArea[row][col] = new Tile(' ');
                    //myArea[row][col] = null;
                    //DECREMENT TILE COUNT SOMEHOW
                    //state.decrementTileCount();
                    //tileCount--;
                    disappearedTiles++;
                }
            }
        }
        
        //Collapses down or in if necessary.
        collapseDown();
        collapseIn();
        collapseIn();
        
        //state.addUndoableMove(myArea);
        
        return myArea;
    }
    
    /**
     * Sets the value in the playing area corresponding to
     * the row index and column index to null to represent a tile
     * being clicked.
     * 
     * @param rowIndex - row of click
     * @param columnIndex - col of click
     * @return updated playing area
     */
    public MyRenderable[][] doRightMove(int rowIndex, int columnIndex)
    {
        return myArea;
    }
    
    /**
     * Checks neighbors of clicked on tile.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     */
    public void checkNeighbors(int rowIndex, int columnIndex)
    {
        
        char mySymbol = myArea[rowIndex][columnIndex].getSymbol();
        
        //Checks if there is a neighbor of same color
        //Setting tile to disappear if any matches
        //Checks left
        if (checkDirection(rowIndex, columnIndex, mySymbol, Direction.LEFT))
        {
            myArea[rowIndex][columnIndex].setDisappear();
        }
        //Checks right
        if (checkDirection(rowIndex, columnIndex, mySymbol, Direction.RIGHT))
        {
            myArea[rowIndex][columnIndex].setDisappear();
        }
        //Checks up
        if (checkDirection(rowIndex, columnIndex, mySymbol, Direction.UP))
        {
            myArea[rowIndex][columnIndex].setDisappear();
        }
        //Checks down
        if (checkDirection(rowIndex, columnIndex, mySymbol, Direction.DOWN))
        {
            myArea[rowIndex][columnIndex].setDisappear();
        }
       
    }
    
    /**
     * Checks if the neighboring tile to the specified direction
     * is of the same color/symbol as the current tile.
     * 
     * @param rowIndex - row index
     * @param columnIndex - column index
     * @param symbol - symbol of the current tile
     * @param dir - direction to check neighbor
     * @return whether or not a neighbor is the same color
     */
    private boolean checkDirection(int rowIndex, 
        int columnIndex, char symbol, Direction dir)
    {
        int newRow = rowIndex;
        int newCol = columnIndex;
        
        //Checks if direction is up and changes row
        if (dir == Direction.UP)
        {
            newRow--;
        }
        //checks if direction is down and changes row
        if (dir == Direction.DOWN)
        {
            newRow++;
        }
        //checks if direction is left and changes col
        if (dir == Direction.LEFT)
        {
            newCol--;
        }
        //checks if direction is right and changes col
        if (dir == Direction.RIGHT)
        {
            newCol++;
        }
        
        //Makes sure new row/col is not out of bounds
        if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size)
        {
            //Checks if neighbor has the same symbol
            if (myArea[newRow][newCol].getSymbol() == symbol)
            //if (myArea[newRow][newCol] != null && 
            //    myArea[newRow][newCol].getSymbol() == symbol)
            {
                //Sets current tile to be destroyed
                myArea[rowIndex][columnIndex].setDisappear();
                //myArea[newRow][newCol].setDisappear();
                
                //Checks neighbors of the neighbor if the tile is not already
                //set to be destroyed.
                if (!myArea[newRow][newCol].willDisappear())
                {
                    checkNeighbors(newRow, newCol);
                }
                
                return true;
            }
        }
        
        return false;
    }

    /**
     * Collapses the tiles in the playing area down.
     * To be called after a click on a tile has been made.
     * Only changes playing area if tiles have disappeared.
     * 
     * @return the collapsed playing area 
     */
    public Tile[][] collapseDown()
    {
        int curRow;             // Keeps track of which row collapse is on
        int lastRow;            // Keeps track of previous row
        //Runs through each row of the playing area
        for (int row = 0; row < size; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < size; col++)
            {
                //Checks if spot in playing area is null
                //if (myArea[row][col] == null)
                if (myArea[row][col].getSymbol() == ' ')
                {
                    lastRow = row;
                    curRow = row - 1;
                    // moves down tiles
                    while (curRow >= 0)
                    {
                        //Checks that tile above current tile is not null
                        if (myArea[curRow][col].getSymbol() != ' ')
                        //if (myArea[curRow][col] != null)
                        {
                            //Sets the null spot to non-null tile above it.
                            myArea[lastRow][col] = new Tile(
                                myArea[curRow][col].getSymbol());
                            //Sets the current tile to null
                            //effectively moving down a tile a spot
                            //myArea[curRow][col] = null;
                            myArea[curRow][col] = new Tile(' ');
                        }
                        //Decrements (goes up in area) the rows
                        lastRow--;
                        curRow--;
                    }
                }
                
            }
        }
        return myArea;
    }
    
    /**
     * Collapses the tiles in the playing area towards center 
     * if there is an empty column.
     * To be called after a click on a tile has been made.
     * Only changes playing area if tiles have disappeared.
     * 
     * @return the collapsed playing area 
     */
    public Tile[][] collapseIn()
    {
        int missingTileCounter = 0;
        
        //Runs through each row of the playing area
        //Doesn't check first/last column
        for (int col = 1; col < size - 1; col++)
        {
            missingTileCounter = 0;
            //Runs through each column of the playing area
            for (int row = 0; row < size; row++)
            {
                //Checks if tile is disappeared in current column
                if (myArea[row][col].getSymbol() == ' ')
                //if (myArea[row][col] == null)
                {
                    missingTileCounter++;
                }
                
                //Checks if all tiles are missing in column
                if (missingTileCounter == size)
                {
                    moveColumn(col);
                }
            }
        }
        
        return myArea;
        
    }
    
    /**
     * Moves tiles to from neighboring column into the missing column.
     * Effectively collapsing the playing area towards the center.
     * @param missingCol - column that needs to be filled in.
     */
    private void moveColumn(int missingCol)
    {
        //Used to check if should move from left or right
        int midPoint = size / 2;   
        //Column being moved in to missing col
        int colToBeMoved = missingCol; 
        
        //Checks if tiles from left/right should be moved into column
        if (missingCol < midPoint)
        {
            //Moved in from left 
            colToBeMoved--;
        }
        else
        {
            //Moved in from right
            colToBeMoved++;
        }
        
        //Checks to see if column is in playing area
        if (colToBeMoved >= 0 && colToBeMoved < size)
        {
            //moves all rows into new column.
            for (int row = 0; row < size; row++)
            {
                //Checks if tile to be moved isn't null
                if (myArea[row][colToBeMoved].getSymbol() != ' ')
                //if (myArea[row][colToBeMoved] != null)
                {
                    myArea[row][missingCol] = 
                        new Tile(myArea[row][colToBeMoved].getSymbol());
                }
                //Sets to null if tile to be moved is null
                else
                {
                    //myArea[row][missingCol] = null;
                    myArea[row][missingCol] = new Tile(' ');
                }
                //Sets
                //myArea[row][colToBeMoved] = null;
                myArea[row][colToBeMoved] = new Tile(' ');
            }
            //Makes sure there isn't a gap column
            moveColumn(colToBeMoved);
        }  
        
    }
}
