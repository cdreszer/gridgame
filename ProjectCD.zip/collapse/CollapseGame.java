package collapse;

import gridgames.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * The ObservableArea contains the status and playing area.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class CollapseGame extends GridGame
{
    private CollapsePlayingArea area;
    private GameClock clock;
    private Preferences preferences;
    private boolean hasWon;
    private boolean showHOF = false;
    //private boolean hasQuit;
    private int size;
    private final int kSizeOfHOF = 5;
    
    /**
     * Creates a new collapse game.
     * Initialize the board to a random configuration. 
     */
    public CollapseGame()
    {
        super();
        size = super.initialSize();
        preferences = getPreferences();
        clock = super.getClock();
        area = new CollapsePlayingArea(this.size);
        hasWon = false;
    }
    
    /**
     * Creates a new collapse game by reading a predefined board 
     * configuration with which to start the game.
     * @param scan Scanner from which a board configuration is read. 
     */
    public CollapseGame(Scanner scan)
    {
        //super();
        size = super.initialSize();
        preferences = getPreferences();
        //area = (CollapsePlayingArea) super.getArea();
        area = new CollapsePlayingArea(size);
        area = (CollapsePlayingArea) setGridGame(area, scan);
        
        clock = super.getClock();
        hasWon = false;
        refresh();
    }
    
    /**
     * Returns the size of the game.
     * @return size of the board
     */
    public int getSize()
    {
        size = area.getColumnCount();
        return size;
    }
    
    /**
     * Returns the status panel as a string to be put into "status".
     * @return a string representing the status of the game.
     */
    public String getStatus()
    {   
        return "Tiles left: " + area.getTileCount() + 
                "    Moves: " + area.getMoveCount() + "  " + 
                clock.getTime();
    }
    
    /**
     * Returns the PlayingArea of the game.
     * @return the playing area
     */
    @Override
    public PlayingArea getArea()
    {
        return area;
    }
    
        
    /**
     * Carries out the game logic for the specified value being clicked.
     * @param rowIndex - row location of click
     * @param columnIndex - col location of click
     */
    public void valueAtLeftClicked(int rowIndex, int columnIndex)
    {
        //Checks to see if the value selected is empty
        if (((Tile)(area.getValueAt(rowIndex, columnIndex))).getSymbol() != ' ')
        {
            //sets corresponding spot in playing area
            area.valueAtLeftClicked(rowIndex, columnIndex);
            
            setChanged();
            notifyObservers();
        }
        
        //Checks if tile count is at 0
        if (area.getTileCount() == 0)
        {
            clock.stopTimer();
            
        }
    }
    
    /**
     * Does nothing in the case of the Collapse game.
     * @param rowIndex - row location of click
     * @param columnIndex - col location of click
     */
    public void valueAtRightClicked(int rowIndex, int columnIndex)
    {
    }
    
    /**
     * Restarts the game.
     */
    public void restartGame()
    {
        //restarts click count and resets up same playing area
        area.restartArea(); 
        //resets status panel
        clock.resetTimer();
        refresh();
    }
    
    /**
     * Creates a new game.
     */
    public void newGame()
    {
        // Tree of sections -> options/values
        TreeMap<String, TreeMap<String, String>> prefs = 
            preferences.getPreferenceValues();
        //Tree of sections -> options
        TreeMap<String, String> curPreferences = 
            preferences.getCurPreferences();
        //Sets new board size
        String curBoard = curPreferences.get("Board Size");
        String newSize = prefs.get("Board Size").get(curBoard);

        area.setSize(Integer.parseInt(newSize));
        
        
        //rerandomizes game and resets click count
        area.randomizePlayingArea();
        //reseys timer and prints status
        clock.resetTimer();
        refresh();
    }
    
    /**
     * Performs an undo on the game.
     */
    public void undoMove()
    {
        //checks if any undoablemoves
        if (area.canUndo())
        {
            //Increments click count and undos last move
            area.undoArea();
            refresh();
        }

    }
    
    /**
     * Checks to see if the game has been won
     * @return whether or not the game has been won
     */
    public boolean hasWon()
    {
        //Checks to see if any tiles are left.
        if (area.getTileCount() == 0)
        {
            hasWon = true;
        }
        else
        {
            hasWon = false;
        }
        
        return hasWon;
    }
    
    /**
     * Returns a list of menu actions for the observable game.
     * @return list of menu actions
     */
    public List<Action> getMenuActions()
    {
        //Creates menu actions
        Action restart = new RestartAction("Restart", null, KeyEvent.VK_R, this);
        Action newGame = new NewGameAction("New Game", null, KeyEvent.VK_N, this);
        Action undo = new UndoAction("Undo", null, KeyEvent.VK_U, this);
        Action hof = new HOFAction("Hall", null, KeyEvent.VK_H, this);
        Action quit = new QuitAction("Quit", null, KeyEvent.VK_Q, this);
        
        List<Action> actions = new ArrayList<Action>();
        
        //adds menu actions
        actions.add(restart);
        actions.add(newGame);
        actions.add(undo);
        actions.add(hof);
        actions.add(quit);
        
        return actions;
    }
    
    /**
     * Returns a list of preference actions for the observable game.
     * @return list of pref actions
     */
    public List<Action> getPreferenceActions()
    {
                //creates action list
        List<Action> actions = new ArrayList<Action>();
        //gets key values
        TreeMap<String, String> values = 
            getPreferences().getPreferenceValues().get("Board Size");
            
        //gets small value
        String sSize = values.get("tiny");
        int vSize = Integer.parseInt(sSize);
            
        Action tinyAction = new SizeAction("tiny", null, null, this, vSize);   
            
        //gets small value
        sSize = values.get("small");
        vSize = Integer.parseInt(sSize);
            
        Action smallAction = new SizeAction("small", null, null, this, vSize);

        sSize = values.get("medium");
        vSize = Integer.parseInt(sSize);
            
        Action medAction = new SizeAction("medium", null, null, this, vSize);
        
        sSize = values.get("large");
        vSize = Integer.parseInt(sSize);
            
        Action largeAction = new SizeAction("large", null, null, this, vSize);
        
        actions.add(tinyAction);
        actions.add(smallAction);
        actions.add(medAction);
        actions.add(largeAction);
        
        return actions;
        
    }
    
    /**
     * Returns the path to the background image.
     * Returns null if no background image.
     * 
     * @return background image
     */
    public String getBackgroundImagePath()
    {
        return "collapse/GiraudSkin/backgroundbkgd.jpg";
    }
    
    /**
     * Returns the name of the plug-in.
     * Used when searching for configuration files.
     * @return name of the plug-in
     */
    public String getPluginName()
    {
        return "collapse";
    }
    
    /**
     * Returns the PlayerEntry to be entered into the HOF.
     * @return the HOF player entry
     */
    public PlayerEntry getPlayerEntry()
    {
        PlayerEntry entry = new CollapseEntry("", area.getMoveCount());
        
        return entry;
    }
    
    /**
     * Returns an instance of the HallOfFame for the current game.
     * @return HallOfFame (filename, size, how many to be displayed)
     */
    public HallOfFame<PlayerEntry> getHallOfFame()
    {
        return new HallOfFame<PlayerEntry>("collapse/HOF.txt", kSizeOfHOF, kSizeOfHOF);
    }
}
