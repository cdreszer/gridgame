package collapse;
import gridgames.*;
import java.util.*;

/**
 * The Tile class models the colored, rectangular tiles within the playing area./
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class Tile implements MyRenderable
{
    private static final int kNumColors = 3; //Number of colors
    private char symbol;        //Symbol representing color
    private boolean disappear = false;
    
    private String pkg = "/Collapse/";
    private String skin = "GiraudSkin/";
    private String purple = "piecepurple.jpg";
    private String cyan = "piececyan.jpg";
    private String green = "piecegreen.jpg";
    

    /**
     * Constructor for objects of class Tile
     */
    public Tile()
    {
        // Randomizes Tile
        randomizeColor();
    }
    
    /**
     * Sets tile to specified color/symbol.
     * @param symbol - the symbol to be read in
     */
    public Tile(char symbol)
    {
        this.symbol = symbol;
    }
   
    /**
     * Returns the tile's symbol
     * @return symbol as a char
     */
    public char getSymbol()
    {
        return symbol;
    }
    
    /**
     * Returns whether or not the renderable cell contains an image.
     * 
     * @return whether or not the cell contains an image
     */
    public boolean isImage()
    {
        return true;
    }
    
    /**
     * Returns the text the plug-in author wants to display in a
     * cell. 
     * 
     * @return the text that should be displayed in a cell formatted as 
     *  startTags + text + endTags.
     */
    public String htmlText()
    {
        return kStartTags + symbol + kEndTags;
    }
    
    /**
     * Randomizes the color of the tile.
     * 
     */
    public void randomizeColor()
    {
        //Creates random number from 0-2
        int randomNum = (int) (Math.random() * kNumColors);
        //System.out.println(randomNum);
        
        //If 0 sets color to purple
        if (randomNum == 0)
        {
            //setPurple();
            symbol = 'x';
        }
        //If 1 sets color to cyan
        else if (randomNum == 1)
        {
            //setCyan();
            symbol = 'o';
        }
        //If 2 sets color to green
        else
        {
            //setGreen();
            symbol = '+';
        }
    }
    
    /**
     * Returns whether or not tile will be removed.
     * @return whether or not tile will be removed.
     */
    public boolean willDisappear()
    {
        return disappear;
    }
    
    /**
     * Sets the tile to dissapear, so it will be removed from playing area.
     */
    public void setDisappear()
    {
        disappear = true;
    }
    
    /**
     * Returns the tiles symbol
     * @return symbol
     */
    public String getText() 
    { 
        return "" + symbol; 
    }
    
    /**
     * Returns the tiles symbol.
     * @return symbol
     */
    @Override
    public String toString() 
    { 
        return "" + symbol; 
    }
    
    /**
     * Returns a map of all the renderable token's names 
     * for the grid game mapped with the file path to their images, if anything.
     * 
     * Key = piece name
     * Value = path to image
     * 
     * @return map of piece names and images
     */
    public Map<Character, String> getRenderableImageMap()
    {
        Map<Character, String> tileImages = new HashMap<Character, String>();
        
        tileImages.put('x', pkg + skin + purple);
        tileImages.put('o', pkg + skin + cyan);
        tileImages.put('+', pkg + skin + green);
        
        return tileImages;
    }

}
