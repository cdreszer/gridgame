package collapse;

import java.util.*;

/**
 * The test class TileTest.
 *
 * @author  Chase Dreszer
 * @version Oct 2015
 */
public class TileTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class TileTest
     */
    public TileTest()
    {
    }
    
    /**
     * Tests tile constructor when passed a symbol or passed nothing.
     */
    public void testTile()
    {
        Tile tile = new Tile('x');
        //assertEquals(tile.getColor(), Tile.Color.PURPLE);
        assertEquals(tile.getSymbol(), 'x');
        
        tile = new Tile('+');
        //assertEquals(tile.getColor(), Tile.Color.GREEN);
        assertEquals(tile.getSymbol(), '+');
        
        tile = new Tile(' ');
        //assertTrue(tile.getColor() == null);
        assertEquals(tile.getSymbol(), ' ');
        
        tile = new Tile();
        char sym = tile.getSymbol();
        assertTrue(sym == 'x' || sym == 'o' || sym == '+');    
    }
    
    /**
     * Tests the get symbol method.
     */
    public void testGetSymbol()
    {
        Tile tile = new Tile('x');
        assertEquals(tile.getSymbol(), 'x');
        assertFalse(tile.getSymbol() == 'o');
    }
    
    /**
     * Test isDestroyed.
     */
    public void testwillDissapear()
    {
        Tile tile = new Tile();
        assertFalse(tile.willDisappear());
        tile.setDisappear();
        assertTrue(tile.willDisappear());
    }
    
    /**
     * Test set destroyed.
     */
    public void setDestroyed()
    {
        Tile tile = new Tile();
        assertFalse(tile.willDisappear());
        tile.setDisappear();
        assertTrue(tile.willDisappear());
    }
    
    /**
     * Tests randomizing of color.
     */
    public void testRandomizeColor()
    {
        int purpleCount = 0;
        int cyanCount = 0;
        int greenCount = 0;
        
        Tile tile = new Tile();
        
        //Randomizes color 1,000 times
        for (int count = 0; count < 1000; count++)
        {
            tile.randomizeColor();
            //checks if purple
            if (tile.getSymbol() == 'x')
            {
                purpleCount++;
            }
            //checks if cyan
            if (tile.getSymbol() == 'o')
            {
                cyanCount++;
            }
            //checks if green
            if (tile.getSymbol() == '+')
            {
                greenCount++;
            }
        }
        
        assertTrue(purpleCount < 500);
        assertTrue(cyanCount < 500);
        assertTrue(greenCount < 500);
            
    }
    
    /**
     * tests get text
     */
    public void testGetText()
    {
        Tile tile = new Tile('x');
        assertTrue(tile.getText().equals("x"));
        
        tile = new Tile('+');
        assertTrue(tile.getText().equals("+"));
        
        tile = new Tile(' ');
        assertTrue(tile.getText().equals(" "));
    }
    
    /**
     * tests to String
     */
    public void testToString()
    {
        Tile tile = new Tile('x');
        assertTrue(tile.toString().equals("x"));
        
        tile = new Tile('+');
        assertTrue(tile.toString().equals("+"));
        
        tile = new Tile(' ');
        assertTrue(tile.toString().equals(" "));
    }

}
