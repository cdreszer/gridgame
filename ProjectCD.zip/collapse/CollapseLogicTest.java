package collapse;

import gridgames.*;

/**
 * The test class CollapseLogicTest.
 *
 * @author  Chase Dreszer
 * @version Oct 2015
 */
public class CollapseLogicTest extends junit.framework.TestCase
{
    private CollapsePlayingArea area;
    private CollapseLogic logic;
    
    /**
     * Tests check neighbors my building a known playing area and checking
     * if tile is set to will disappear.
     */
    public void testCheckNeighbors()
    {
        Tile tile;
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.checkNeighbors(1, 1);
        
        tile = (Tile) area.getValueAt(1, 0);
        assertTrue(tile.willDisappear());
        
        tile = (Tile) area.getValueAt(1, 1);
        assertTrue(tile.willDisappear());
        
        tile = (Tile) area.getValueAt(1, 2);
        assertTrue(tile.willDisappear());
        
        tile = (Tile) area.getValueAt(0, 1);
        assertFalse(tile.willDisappear());
        
        tile = (Tile) area.getValueAt(2, 1);
        assertFalse(tile.willDisappear());       
    }
    
    /**
     * Tests check if number of disappeared tiles is correct.
     */
    public void testAmountOfDisappearedTiles()
    {   
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.doLeftMove(1, 1);

        assertTrue(logic.amountOfDisappearedTiles() == 3);
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'o');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.doLeftMove(0, 0);
        
        assertTrue(logic.amountOfDisappearedTiles() == 0);
        
    }
    
    /**
     * Tests check if number of disappeared tiles is correct.
     */
    public void testCollapseDown()
    {
        Tile tile;
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, ' ');
        area.setValueAt(2, 1, ' ');
        area.setValueAt(2, 2, ' ');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.collapseDown();
        
        tile = (Tile) area.getValueAt(2, 1);
        assertTrue(tile.getSymbol() == 'o');
    }
    
    /**
     * Tests check if number of disappeared tiles is correct.
     */
    public void testCollapseIn()
    {
        Tile tile;
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, ' ');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'x');
        area.setValueAt(1, 1, ' ');
        area.setValueAt(1, 2, 'x');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, ' ');
        area.setValueAt(2, 2, '+');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.collapseIn();
        
        tile = (Tile) area.getValueAt(2, 1);
        assertTrue(tile.getSymbol() == '+');
        
        area = new CollapsePlayingArea(5);
        //Runs through each row of the playing area
        for (int row = 0; row < 5; row++)
        {
            //Runs through each column of the playing area
            for (int col = 0; col < 5; col++)
            {
                //Sets every tile to 'x'
                area.setValueAt(row, col, 'x');
            }
        }
        
        //Runs through each row of the playing area
        for (int row = 0; row < 5; row++)
        {
            //Runs through each column of the playing area
            for (int col = 2; col < 4; col++)
            {
                //Sets every tile to 'x'
                area.setValueAt(row, col, ' ');
            }
        }
        
        tile = (Tile) area.getValueAt(0, 3);
        assertTrue(tile.getSymbol() == ' ');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.collapseIn();
        
        tile = (Tile) area.getValueAt(0, 3);
        assertTrue(tile.getSymbol() == 'x');
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, ' ');
        area.setValueAt(0, 1, 'x');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, ' ');
        area.setValueAt(1, 1, 'x');
        area.setValueAt(1, 2, 'x');
        area.setValueAt(2, 0, ' ');
        area.setValueAt(2, 1, '+');
        area.setValueAt(2, 2, '+');
        
        tile = (Tile) area.getValueAt(0, 0);
        assertTrue(tile.getSymbol() == ' ');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.collapseIn();
        
        tile = (Tile) area.getValueAt(0, 0);
        assertTrue(tile.getSymbol() == ' ');
        
        area = new CollapsePlayingArea(4);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, ' ');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(0, 3, 'x');
        area.setValueAt(1, 0, 'x');
        area.setValueAt(1, 1, ' ');
        area.setValueAt(1, 2, ' ');
        area.setValueAt(1, 3, 'x');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, ' ');
        area.setValueAt(2, 2, 'x');
        area.setValueAt(2, 3, 'x');
        area.setValueAt(3, 0, '+');
        area.setValueAt(3, 1, ' ');
        area.setValueAt(3, 2, 'x');
        area.setValueAt(3, 3, ' ');
        
        tile = (Tile) area.getValueAt(0, 1);
        assertTrue(tile.getSymbol() == ' ');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.collapseIn();
        
        tile = (Tile) area.getValueAt(0, 2);
        assertTrue(tile.getSymbol() == 'x');
    }
    
    /**
     * Tests doing a move in collapse game.
     */
    public void testDoMove()
    {
        Tile tile;
        
        area = new CollapsePlayingArea(3);
        area.setValueAt(0, 0, 'x');
        area.setValueAt(0, 1, 'o');
        area.setValueAt(0, 2, 'x');
        area.setValueAt(1, 0, 'o');
        area.setValueAt(1, 1, 'o');
        area.setValueAt(1, 2, 'o');
        area.setValueAt(2, 0, '+');
        area.setValueAt(2, 1, 'x');
        area.setValueAt(2, 2, '+');
        
        logic = new CollapseLogic(area.getArea(), area.getRowCount());
        logic.doLeftMove(1, 1);

        assertTrue(logic.amountOfDisappearedTiles() == 4);
        
        tile = (Tile) area.getValueAt(0, 1);
        assertTrue(tile.getSymbol() == ' ');
        
        logic.doLeftMove(2, 1);
        
        assertTrue(logic.amountOfDisappearedTiles() == 0);
        
        tile = (Tile) area.getValueAt(2, 1);
        assertTrue(tile.getSymbol() == 'x');
        
    }
    
}
