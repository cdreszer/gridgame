package gridgameviews;

import gridgames.*;
import collapse.*;

import java.util.*;
import java.io.*;

/**
 * The class GridGameConsoleTest tests Collapse Console.
 *
 * @author  Chase Dreszer
 * @version Nov 2015
 */
public class GridGameConsoleTest extends junit.framework.TestCase
{
    private CollapseGame game;
    private GridGameConsole console;
    private String output = "outputfile.txt";
    private String input = "inputfile.txt";
    private String expected = "expectedout.txt";
    
    /**
     * Tests run.
     */
    public void testRun()
    {
        setUp();
        String allOut = "";
        String allExpected = "";
        
        game.addObserver(console);
        game.startGame();
        console.run();
        
        try
        {
            File file = new File(output);
            Scanner oScan = new Scanner(file);
            File expectedOut = new File(expected);
            Scanner eScan = new Scanner(expectedOut);
            
            while (oScan.hasNextLine())
            {
                String curLine = oScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                allOut += curLine + "\n";
            }
            while (eScan.hasNextLine())
            {
                String curLine = eScan.nextLine();
                
                if (curLine.contains("0:0"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                
                allExpected += curLine + "\n";
            }
            
            assertEquals(allExpected, allOut);
            
        }
        catch(FileNotFoundException exception)
        {
            System.out.println("Test run 1 failed. (no file)");
        } 
    }
    
    /**
     * Makes sure no errors are thrown when inputting null input and output
     * for console.
     */
    public void testNullInputAndOutput()
    {
        setUp();
        
        try 
        {
            console = new GridGameConsole(game, null, null);
            console = new GridGameConsole(game, null, output);
            console = new GridGameConsole(game, input, null);             
        }
        catch (FileNotFoundException exception)
        {
            System.out.println("No test file found.");
        }
    }
    
    /**
     * Tests run.
     */
    public void testRun2()
    {   
        
        input = "inputfile2.txt";
        output = "outputfile2.txt";
        expected = "expectedout2.txt";
        
        String allOut = "";
        String allExpected = "";
        
        try
        {
             //Creates the game from boardfile.
            File board = new File("test.txt");
            Scanner scan = new Scanner(board);
            game = new CollapseGame(scan);
            console = new GridGameConsole(game, input, output);  
            
            
            game.addObserver(console);
            game.startGame();
            console.run();
            
            File file = new File(output);
            Scanner oScan = new Scanner(file);
            
            File expectedOut2 = new File(expected);
            Scanner eScan = new Scanner(expectedOut2);
            
            while (oScan.hasNextLine())
            {
                String curLine = oScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                allOut += curLine + "\n";
            }
            while (eScan.hasNextLine())
            {
                String curLine = eScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                
                allExpected += curLine + "\n";
            }
            
            assertEquals(((CollapsePlayingArea)game.getArea()).getTileCount(), 25);
            
            assertEquals(allExpected, allOut);
        }
        catch(FileNotFoundException exception)
        {
            System.out.println("Test run 2 failed. (no file)");
        } 
        
    }
    
        /**
     * Tests run.
     */
    public void testRunLarge()
    {   
        
        input = "inputfile3.txt";
        output = "outputfile3.txt";
        expected = "expectedout3.txt";
        
        String allOut = "";
        String allExpected = "";
        
        try
        {
             //Creates the game from boardfile.
            File board = new File("largeboard.txt");
            Scanner scan = new Scanner(board);
            game = new CollapseGame(scan);
            console = new GridGameConsole(game, input, output);  
            assertEquals(((CollapsePlayingArea)game.getArea()).getTileCount(), 144);
            
            game.addObserver(console);
            game.startGame();
            console.run();
            
            File file = new File(output);
            Scanner oScan = new Scanner(file);
            
            File expectedOut2 = new File(expected);
            Scanner eScan = new Scanner(expectedOut2);
            
            while (oScan.hasNextLine())
            {
                String curLine = oScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                allOut += curLine + "\n";
            }
            while (eScan.hasNextLine())
            {
                String curLine = eScan.nextLine();
                
                if (curLine.contains("0:"))
                {
                    int indexOfTime = curLine.indexOf("0:");
                    curLine = curLine.substring(0, indexOfTime);
                }
                
                allExpected += curLine + "\n";
            }
            
            assertEquals(((CollapsePlayingArea)game.getArea()).getTileCount(), 0);
            
            assertEquals(allExpected, allOut);
        }
        catch(FileNotFoundException exception)
        {
            System.out.println("Test run large board failed. (no file)");
        } 
        
    }
    
    public void testNewGame()
    {
        input = "newgameinput.txt";
        
        setUp();
        
        game.addObserver(console);
        game.startGame();
        console.run();
        
        assertEquals(((CollapsePlayingArea)game.getArea()).getTileCount(), 25);
        assertEquals(((CollapsePlayingArea)game.getArea()).getMoveCount(), 0);
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
        /*
        try 
        {
            Files.delete("outputfile.txt");
        } 
        catch (NoSuchFileException exception) 
        {
            System.out.println("Problem deleting output file.");
        }
        */
    }
    
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
        try 
        {
            //Creates the game from boardfile.
            File file = new File("test.txt");
            Scanner scan = new Scanner(file);
            game = new CollapseGame(scan);
            console = new GridGameConsole(game, input, output);              
        }
        catch (FileNotFoundException exception)
        {
            System.out.println("No test file found.");
        }
    }
}
