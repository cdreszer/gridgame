package gridgameviews;

import gridgames.*;
//import Collapse.*;

import java.util.*;
import java.io.*;

/**
 * The CollapseConsole class displays the Collapse game in the console
 * and allows for users to make moves from the console that will
 * change the display of the game in the GUI as well as dynamically
 * change the display of the GUI.
 * 
 * @author Chase Dreszer
 * @version Oct 2015
 */
public class GridGameConsole implements Observer
{

    private GridGame game;        // The observable game
    private Scanner scanner;            // What to read from
    private PrintWriter writer;         
    private int size;                   // Size of playing area
    private boolean hasQuit;            // Whether the game has been quit
    private String inputFile;           // Input file
    private String outputFile;          // Output file
    private String columnTitle;
    private String pluginTitle;
    
    private final int kDoubleDigits = 10;
    private final int kStartOfCols = 1;
    private final char kStartOfRows = 'A';
    private final char kStartOfPrefs = 'a';
    private final int kAsciiAValue = 65;
    private final int kAscii0Value = 48;
    private final char kMenuOptionStart = '1';
    private final char kMenuOptionEnd = '4';
    
    /**
     * Constructs the CollapseConsole.
     * 
     * @param game - the observable game
     * @param input - the input file to read inputs from
     * @param output - the output file to write outputs to
     */
    public GridGameConsole(GridGame game, String input, String output)
        throws FileNotFoundException
    {
        hasQuit = false;
        //Sets the area, state, scanner, and size of playing area
        this.game = game;
        pluginTitle = game.getPluginName();
        size = game.getSize();
        //Checks to see if given input file
        if (input == null)
        {
            scanner = new Scanner(System.in);
        }
        else
        {
            inputFile = input;
            File file = new File(inputFile);
            scanner = new Scanner(file);
        }
        
        //Checks to see if given output file
        if (output == null)
        {
            writer = new PrintWriter(System.out);
        }
        else
        {
            outputFile = output;
            File file = new File(outputFile);
            writer = new PrintWriter(outputFile);
        }

        printGameDisplay();
    
    }
    
    /**
     * Performs the menu option selected by the user.
     *  1. Restart
     *  2. New Game
     *  3. Undo
     *  4. Quit
     * @param option - the menu option chosen
     */
    public void performMenuAction(int option)
    {   
        //Checks to see if option is to clear HOF
        if (option == 0)
        {
            HallOfFame hof = game.getHallOfFame();
            hof.clear();
            writer.println("Hall of Fame cleared.");
            writer.flush();
        }
        //Checks to see if option is to show Preferences
        else if (option == game.getMenuActions().size() + 1)
        {
            Preferences pref = game.getPreferences();
            String menu = pref.getPreferencesConsoleMenu();
            writer.println(menu);
            writer.flush();
            
            String prefInput = "";
            //Checks if there was input
            if (!hasQuit && scanner.hasNext()) 
            {
                prefInput = scanner.next();
            }
            
            //Runs through each character of pref command
            for (int ndx = 0; ndx < prefInput.length(); ndx++)
            {
                char input = prefInput.charAt(ndx);
                int num = input - kStartOfPrefs;
                //ensures not null
                if (num < game.getPreferenceActions().size())
                {
                    game.getPreferenceActions().get(num).actionPerformed(null);
                }
                else
                {
                    game.newGame();
                }
            }
            
        }
        else
        {
            game.getMenuActions().get(option - 1).actionPerformed(null);
        }

        //Checks to see if option is quit
        if (option == game.getMenuActions().size())
        {
            game.quit();
            hasQuit = true;
            scanner.close();
        }

    }

    /**
     * Runs the Collapse game on the console.
     */
    public void run()
    {
        
        //File file = new File(fileInName);
        String inLine = "";
            
        // reads through the input file, registering moves and menu selections.
        // Ends if has quit
        while (!hasQuit && scanner.hasNextLine()) 
        {
            //Gets the next line and gets rid of all extra white space
            inLine = scanner.nextLine();
            inLine = inLine.trim();
            inLine = inLine.toUpperCase();
            
            boolean wasMove;
            
            //Checks to see if right click move
            if (inLine.length() > 1 && inLine.charAt(0) == '.')
            {
                inLine = inLine.substring(1, inLine.length());
                wasMove = moveSelection(inLine, true);
            }
            else
            {
                wasMove = moveSelection(inLine, false);
            }
            
            //Checks to see if there was a move selection already
            if (!wasMove)
            {
                menuSelection(inLine);
            }

        }
        
        //writer.close();
        scanner.close();
    }
    
    /**
     * Checks to see if the input line contains a move selection.
     * If so carries out move if acceptable move.
     * 
     * @param inLine - the input line
     * @param isRightMove - whether or not it is a right move
     * @return whether or not there was a move 
     */
    public boolean moveSelection(String inLine, boolean isRightMove)
    {
        boolean wasMove = false;        //Whether the input was an acceptable move
        int row = -1;                   // row of move
        int col = -1;                   // col of move
        int curChar = 0;                // curChar in input line.
        
        //Checks to see if acceptable row selected.
        if (inLine.length() > 1 && inLine.charAt(curChar) >= kStartOfRows && 
            inLine.charAt(curChar) < kStartOfRows + size)
        {
            wasMove = true;
            //Sets row to first character
            row = inLine.charAt(curChar++) - kAsciiAValue;
            
            //makes sure there aren't any characters non 0-9 in remaining string
            while (curChar < inLine.length())
            {
                //Checks if 0-9
                if (inLine.charAt(curChar) < kAscii0Value 
                    || inLine.charAt(curChar) >= kAscii0Value + kDoubleDigits)
                {
                    wasMove = false;
                }
                //Checks next character
                curChar++;
            }
            
            //Checks if was acceptable input
            if (wasMove)
            {
                //sets column to the rest of the string (1-2 digits)
                col = Integer.parseInt(inLine.substring(1, inLine.length())) 
                    - kStartOfCols;
            }
                        
            //checks to see if acceptable column selected.
            if (col >= 0 && col < size)
            {
                //selects the value entered
                if (!isRightMove)
                {
                    game.valueAtLeftClicked(row, col);
                }
                else
                {
                    game.valueAtRightClicked(row, col);
                }
            }
        }
        
        return wasMove;
    }
    
    
    /**
     * Checks to see if the user inputted a menu selection.
     * If so carries out menu action.
     * @param inLine - the input line
     */
    public void menuSelection(String inLine)
    {
         //Checks to see if a Game option was selected.
        if (inLine.length() == 1 && 
            inLine.charAt(0) >= kMenuOptionStart - 1 && 
            inLine.charAt(0) < kMenuOptionStart + game.getMenuActions().size() + 1)
        {
            //gets the menu option selected
            int optionSelected = Integer.parseInt(inLine.charAt(0) + "");
            //performs the menu action that was selected
            performMenuAction(optionSelected);   
        }
    }
    
    /**
     * Prints the playing area of the observable game.
     *  1. Reprints out the title of game and the status.
     *  2. Displays the current board #s for columns & letters for rows.
     *  3. Gives user option for "Restart", "New Game", "Undo", and "Quit"
     *  4. Prints approproate number of dashes for seperator. (----)
     */
    public void printGameDisplay()
    {
        int numSeperatingDashes = 1;
        int option = 1;
        
        //prints out title and status
        writer.println(pluginTitle);
        writer.println(game.getStatus());
        
        //gets the current size
        size = game.getSize();
        
        //Prints the column labels.
        printColumnTitles();
        
        //Prints row titles and current playing area
        printPlayingArea();
        
        writer.print(" ");
        // Prints out the necessary amount of dashes;
        while (numSeperatingDashes++ < columnTitle.length())
        {
            writer.print("-");
        }
        //prints new line after apporpriate # of dashes
        writer.print("\n");
        
        //Prints out menu options.
        while (option <= game.getMenuActions().size())
        {
            // Finds the name of the menu action.
            writer.print(option + ")" + 
                game.getMenuActions().get(option - 1).getValue(
                    game.getMenuActions().get(option - 1).NAME) + " ");
                    
            option++;
        }
        
        writer.print(option + ")" + "Prefs ");
        
        //Prints a new line and flushes the display to the screen
        writer.println();
        writer.flush();
    }
    
    /**
     * Prints the appropriate column titles according to size and
     * whether or not there are double digit columns.
     */
    public void printColumnTitles()
    {
        //The starting column # (1)
        int colTitle = kStartOfCols;
        
        columnTitle = "     ";

        //prints out column titles
        while (colTitle <= size)
        {
            //Checks to see if column is < 10 for title purposes
            if (colTitle < kDoubleDigits)
            {
                columnTitle += colTitle++;
                //writer.print(colTitle++ + "  ");
            }
            else
            {
                columnTitle += colTitle++ % kDoubleDigits;
                //writer.print(colTitle++ % kDoubleDigits + " ");
            }
            //Prints spaces in between column labels.
            if (colTitle != size + 1)
            {
                columnTitle += "  ";
            }
        }
        //prints out the column titles
        writer.println(columnTitle);
    }
    
    /**
     * Displays the current playing area with appropriately labeled rows.
     */
    public void printPlayingArea()
    {
        //The starting row title ('A')
        char rowTitle = kStartOfRows; 
        
        //Runs through rows of playing area
        for (int row = 0; row < size; row++)
        {
            writer.print(" " + rowTitle++ + ":  ");
            //Runs through columns of playing area
            for (int col = 0; col < size; col++)
            {
                MyRenderable cell = (MyRenderable) 
                    (game.getArea().getValueAt(row, col));
                //checks if in last column
                if (col == size - 1)
                {
                    writer.print(cell.getText() + "\n");
                    //prints a new line.
                }
                else
                {
                    writer.print(cell.getText() + "  ");
                }
            }
            writer.flush();
        }
    } 
    
    /**
     * Shows the HOF dialog.
     */
    private void showHOF()
    {
        HallOfFame hof = game.getHallOfFame();   
        
        //Pops up dialog for HOF.
        writer.println("\nHall of Fame:");
        writer.print(hof.toBeDisplayed());
        writer.println();
        writer.flush();
    }
    
    /**
     * Prompts the user to input their name so that their score will
     * be put in the HOF.
     */
    @SuppressWarnings("unchecked")
    private void showHOFInputDialog()
    {
        HallOfFame hof = game.getHallOfFame();            
        PlayerEntry entry = game.getPlayerEntry();
                 
        //Asks for players name
        writer.println("Your " + entry.getAttributeType() + " of "
            + entry.getAttribute() + " will be entered into the " + 
            "Hall of Fame.\n" + "Enter your name:");
        writer.flush();
                    
         
        String name = "";
        //Checks if there was input
        if (!hasQuit && scanner.hasNext()) 
        {
            name = scanner.next();
        }
        //Sets the name of the HOF entry and adds into HOF.       
        entry.setName(name);
        hof.add(entry);
        //Sets game to be ready tp show HOF
        game.setShowHallOfFame();

    }

    /**
     * Updates the console view whenever needed.
     *  1. Reprints out the title of game and the status.
     *  2. Displays the current board #s for columns & letters for rows.
     *  3. Gives user option for "Restart", "New Game", "Undo", and "Quit"
     * 
     * @param obs - the observable to be updated
     * @param obj - the object to be updated.
     */
    public void update(Observable obs, Object obj)
    {
        //Checks to make sure only timer isn't being updated.
        if (obj == null)
        {
            size = game.getSize(); 
            hasQuit = game.hasQuit();
            
            //Checks if has won and if can enter the hall of fame.
            if (!game.hasQuit() && game.hasWon() && !game.shouldShowHallOfFame())
            {
                game.getClock().stopTimer();
                //Gets the current HOF
                showHOFInputDialog();
            }
            //Checks to make sure game has not been quit.
            else if (!hasQuit && !game.shouldShowHallOfFame())
            {
                printGameDisplay();
            }
            //Checks if should show HOF
            if (!game.hasQuit() && game.shouldShowHallOfFame())
            {
                showHOF();
                game.setNoLongerShowHallOfFame();
                printGameDisplay();
            }
        }
    
    }
}
