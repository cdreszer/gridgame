package gridgameviews;

import org.uispec4j.*;
import org.uispec4j.MenuBar.*;
import org.uispec4j.Window.*;
import org.uispec4j.interception.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * The test class CollapseGUITest.
 *
 * @author  Chase Dreszer
 * @version Oct 2015
 */
public class GridGameGUITest extends junit.framework.TestCase
{

    /**
     * Tests collapse GUI basics.
     */
    public void testGridGameGUI()
    {
        /*
        CollapseGUI view = new CollapseGUI();
        view.layoutGUI();
        */
        /* Note: Window and Table are UISpec4J classes */
        /*
        Window win = new Window(view);
        Table table = win.getTable("table");
        assertTrue(win.getTitle().equals("Collapse by Chase Dreszer"));
        // Inspect one cell of the table
        Renderable tile = (Renderable) table.getContentAt(1, 1, 
            new ModelTableCellValueConverter());
        
        // It should contain the piece symbol.
        assertTrue(tile.getText().equals("o") || tile.getText().equals("x")||
            tile.getText().equals("+"));
        
        TextBox theLabel = win.getTextBox("status");
        assertEquals("Tiles left: 9" + "    " + "Moves: 0" +
            "  ", theLabel.getText().substring(0, 27));
            
        // make a move
        table.click(0, 0);
        
        assertEquals("Moves: 1" +
            "  ", theLabel.getText().substring(17, 27));

        // See if the cell content changed
        tile = (Renderable) table.getContentAt(0, 0, 
            new ModelTableCellValueConverter());
        // Empty table cells contain null.
        //assertEquals(" ", tile.getText());
        //win.dispose();
        */
    }
    
    /**
     * Tests collapse gui with scanner.
     */
    public void testGridGameGUIWithScan()
    {
        /*
        try
        {
            File file = new File("test.txt");
            Scanner scan = new Scanner(file);
            //create GUI from file
            CollapseGUI view = new CollapseGUI(scan);
            view.layoutGUI();
            
            Window win = new Window(view);
            Table table = win.getTable("table");
            
            Renderable tile = (Renderable) table.getContentAt(0, 0, 
                new ModelTableCellValueConverter());
                
            assertEquals("x", tile.getText());
            
            tile = (Renderable) table.getContentAt(3, 0, 
                new ModelTableCellValueConverter());
                
            assertEquals("o", tile.getText());
            
            //Click top left corner
            table.click(0, 0);
            
            //Cheecks to make sure row disappeared
            for (int col = 0; col < 5; col++)
            {
                tile = (Renderable) table.getContentAt(0, col, 
                    new ModelTableCellValueConverter());
                
                assertEquals(" ", tile.getText());
            }
        */    
            /*
            MenuItem restart = win.getMenuBar().getMenu(
                "Game").getSubMenu("Restart");
                
            MenuItem newGame = win.getMenuBar().getMenu(
                "Game").getSubMenu("New Game");
            
            MenuItem undo = win.getMenuBar().getMenu(
                "Game").getSubMenu("Undo");
                
            MenuItem quit = win.getMenuBar().getMenu(
                "Game").getSubMenu("Quit");
                
            restart.triggerClick();
            */
      /*      
        }
        catch (FileNotFoundException error) 
        {
            System.out.println("Error: File not found.");
        }
        */
    }
    
    /**
     * Tests menu bar.
     */
    public void testMenuBar()
    {
        /*
        CollapseGUI view = new CollapseGUI();
        view.layoutGUI();
        
        // Note: Window and Table are UISpec4J classes 
        Window win = new Window(view);
        
        MenuBar menuBar = win.getMenuBar();
        MenuItem game = menuBar.getMenu("Game");
        MenuItem preferences = menuBar.getMenu("Preferences");
        */
       
    }
}
