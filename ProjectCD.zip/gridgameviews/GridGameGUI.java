package gridgameviews;

import gridgames.*;
//import Collapse.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.imageio.ImageIO;
import java.util.*;

/**
 * The GridGameGUI class sets up the GUI for the Collapse application.
 * In doing so it sets up the menu bar, status display, and playing area.
 * 
 * @author Chase Dreszer 
 * @author jdalbey (stucture / original javadoc comments)
 */
public final class GridGameGUI extends JFrame implements Observer 
{
    /* Main components of the GUI */
    private JTable table; // DO NOT CHANGE THIS LINE
    private JLabel status; // DO NOT CHANGE THIS LINE
    private JPanel statusPane;  // where status is added
    
    // The underlying data model
    //private PlayingArea myArea;
    private GridGame game;
    //The name of the game.
    private String gameName;
    
    //Menu bar and game state
    private javax.swing.JMenuBar menuBar = new javax.swing.JMenuBar();

    //whether or not the GUI is configured.
    private boolean isConfigured;

    // The images to be displayed
    private ImageIcon background;
    /* Image dimensions, in pixels */
    public final static int kCellWidth = 65;
    public final static int kCellHeight = 43;
    
    /** Prepare the GUI before starting the game.
     *  Initialize the board to a random configuration. 
     *  @param game - the observable game
     */
    public GridGameGUI(GridGame game)
    {
        super();
        //isConfigured = false;
        
        //makes a new instance of a game
        this.game = game;
        this.gameName = game.getPluginName();
        //builds status panel so can send to menu bar
        setupStatusPanel();
        // MENU BAR
        //menuBar = new javax.swing.JMenuBar();
        setupGameMenu();
        setupPreferencesMenu();
        //menuBarHandler = new CollapseMenuBar(this, menuBar, game, status);
        // Adds status panel after adding menu bar.
        //myArea.setSize(menuBarHandler.getDefaultSize());
        
        setJMenuBar(menuBar);
        //update(null, null);
    }
    
    /**
     * Checks to see if board is preconfigured.
     * @return whether or not the board is configured.
     */
    public boolean getIsConfigured()
    {
        return isConfigured;
    }

    /** Place all the Swing widgets in the frame of this GUI.
     * Load the default skin.
     * Prepare a grid of pieces with a background image.
     * Setup the Game and Preference menus.
     * @post the GUI is ready to be made visible.  
     */
    public void layoutGUI()
    {
        setTitle(gameName);
        
        //Sets background image
        background = new ImageIcon(Toolkit.getDefaultToolkit().getImage(
                    this.getClass().getResource(
                        "../" + game.getBackgroundImagePath())));
        
        // Define the layout manager that will control order of components
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        
        getContentPane().add(statusPane);

        //Sets up table to have model data (PlayingArea)
        setUpTable();
        
        // Adds a window listener to notify the game when it has been closed
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent closing)
            {
                game.setHasQuit();
                game.refresh();
            }
        });
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
    /**
     * Sets up "Game" menu onto menuBar.
     * 
     */
    public void setupGameMenu()
    {
        JMenu gameMenu;
        //Creates the Game menu
        gameMenu = new JMenu("Game");
        menuBar.add(gameMenu);
        
        java.util.List<Action> actions = game.getMenuActions();
        // Adds all the actions for the game
        for (Action act : actions)
        {
            JMenuItem item = new JMenuItem(act);
            gameMenu.add(item);
        }
    }
    
    /**
     * Sets up the configurable preferences for the game by reading the
     * preferences.ini file.
     */
    public void setupPreferencesMenu()
    {       
        //Creates Preferences menu
        Preferences pref = game.getPreferences();
        menuBar.add(pref.getMenu());
    }
    
    /**
     * Sets up the table with the playing area.
     */
    public void setUpTable()
    {
        table = new ImageJTable(game.getArea());
        
        /* Define the characteristics of the table that shows the game board    */
        // Set the dimensions for each column in the board to match the image 
        for (int col = 0; col < game.getArea().getColumnCount(); col++)
        {
            TableColumn column = table.getColumnModel().getColumn(col);
            column.setMaxWidth(kCellWidth);
            column.setMinWidth(kCellWidth);
        }
        
        // remove editor makes table not editable
        table.setDefaultEditor(Object.class, null);  
        // define how cell selection works
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setCellSelectionEnabled(false);
        // other miscellaneous settings
        table.setName("table");  // DO NOT CHANGE THIS LINE       
        // Read "How to use Tables" in Java Swing Tutorial
        //Sets renderer to Tile Renderer
        table.setDefaultRenderer(MyRenderable.class, new CellRenderer());        
        table.setRowHeight(kCellHeight);
        table.setOpaque(false);
        table.setShowGrid(false);
        table.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Add a custom mouse listener that will handle player's clicks.
        table.addMouseListener(myMouseListener);
        // finally, add the table to the content pane
        getContentPane().add(table);
        pack();
    }
    
    /* Listener to respond to mouse clicks on the table */
    private MouseAdapter myMouseListener = new MouseAdapter()
        {
            public void mouseReleased(MouseEvent ev)
            {
                // obtain the selected cell coordinates
                int col = table.getSelectedColumn();
                int row = table.getSelectedRow();
                
                //checks to see if right mouse click
                if (SwingUtilities.isRightMouseButton(ev)) 
                {
                    row = (int) (ev.getPoint().getY() / kCellHeight);
                    col = (int) (ev.getPoint().getX() / kCellWidth);
                    
                    game.valueAtRightClicked(row, col);
                }
                else
                {
                    //States tile was clicked.
                    // left mouse click
                    game.valueAtLeftClicked(row, col);
                }
                
                
                //currentTime = System.currentTimeMillis() - startTime;
                status.setText(game.getStatus());

                repaint();
            }
        };  // end mouse listener
    
    /**
     * Sets up the status panel for the collapse game.
     * Status panel displays how many tiles remain on the board,
     * how many moves are completed, and the elapsed time.
     */
    public void setupStatusPanel()
    {
        statusPane = new JPanel();
        //currentTime = System.currentTimeMillis() - startTime;
        status = new JLabel(game.getStatus());
        status.setName("status");  // DO NOT CHANGE THIS LINE       
        statusPane.add(status);    
        statusPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        
    }
    
    /**
     * Updates the GUI with the Observable Game data.
     * 
     * @param obs - the observable to be updated
     * @param obj - the object to be updated.
     */
    @SuppressWarnings("unchecked")
    public void update(Observable obs, Object obj)
    {  
        status.setText(game.getStatus());
        //Resets up columns
        for (int col = 0; col < game.getSize(); col++)
        {
            TableColumn column = table.getColumnModel().getColumn(col);
            column.setMaxWidth(kCellWidth);
            column.setMinWidth(kCellWidth);
        }

        pack();
        
        //Checks to see if quit out app.
        if (game.hasQuit())
        {
            this.dispose();
        }
        //Checks if has won and if can enter the hall of fame.
        else if (game.hasWon() && obj == null)
        {
            game.getClock().stopTimer();
            
            //Gets the current HOF
            HallOfFame hof = game.getHallOfFame();            
            PlayerEntry entry = game.getPlayerEntry();
            
            //Asks for players name
            String name = (String) JOptionPane.showInputDialog(
                    this,
                    "Your " + entry.getAttributeType() + " of "
                    + entry.getAttribute() + " will be entered into the " + 
                    "Hall of Fame.\n" + "Enter your name:",
                    "Name Entry",
                    JOptionPane.PLAIN_MESSAGE);
            
            //Sets the name of the HOF entry and adds into HOF.
            entry.setName(name);
            hof.add(entry);
           
            showHOF();
                 
        }
        //Checks if should show HOF
        if (game.shouldShowHallOfFame())
        {
            showHOF();
            game.setNoLongerShowHallOfFame();
        }
    }
    
    /**
     * Shows the HOF dialog.
     */
    private void showHOF()
    {
        HallOfFame hof = game.getHallOfFame();   
        
        //Pops up dialog for HOF.
        JOptionPane.showMessageDialog(this,
            hof.toBeDisplayed(),
            "Hall of Fame",
            JOptionPane.PLAIN_MESSAGE);
    }
    
    /** Our custom JTable has special features for displaying images and 
     *  a background.
     */
    private class ImageJTable extends JTable
    {
        public ImageJTable(AbstractTableModel data)
        {
            super(data);
        }

        //  Tell JTable it should expect each column to contain Renderable things,
        //  and should select the corresponding renderer for displaying it.
        public Class getColumnClass(int column)
        {
            return MyRenderable.class;
        }
        //  Allow the background to be displayed
        public Component prepareRenderer(TableCellRenderer renderer, int row,
        int column)
        {
            Component component = super.prepareRenderer(renderer, row, column);
            // We want renderer component to be
            // transparent so background image is visible
            if (component instanceof JComponent)
            {
                ((JComponent) component).setOpaque(false);
            }
            return component;
        }

        // Override paint so as to show the table background
        public void paint(Graphics gfx)
        {
            // paint an image in the table background
            if (background != null)
            {
                gfx.drawImage(background.getImage(), 0, 0, null, null);
            }
            // Now let the paint do its usual work
            super.paint(gfx);
        }

    } // end ImageJTable
    
}